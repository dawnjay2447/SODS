import { ObjectKey } from './../model/objectKey';
import { element } from 'protractor';
import { Injectable, ElementRef } from '@angular/core';
import { Http, Response, Headers, RequestOptions, ResponseContentType } from '@angular/http';
import { Event, ActionSubscriber } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from '../events/action-events';
import { contentHeaders } from '../democomponents/util/headers';
import { environment } from '../../environments/environment';
import { ResponseMapper } from '../democomponents/util/response-mapper';
import { Observable } from 'rxjs/Rx';

//import model
import { Requisition, SAMPLEREQUISITION } from '../model/requisition';
import { Customer, SAMPLECUSTOMER } from '../model/customer';
import { Product, SAMPLEProduct, SAMPLEProduct_B } from '../model/product';
import { DivisionUser, SAMPLEDivisionUserBuyer, SAMPLEDivisionUserCA } from '../model/divisionrole';
import { Attachment, SAMPLEATTACHMENT_A, SAMPLEATTACHMENT_B } from '../model/attachment';
import { SAMPLETandemTM, TandemTM } from '../model/tandemTM';
import { UsfUser } from '../model/usfuser';
import { Header, SAMPLEHEADER } from '../model/header';
import { fileSaver, saveAs } from 'file-saver';
import { Division } from '../model/division';
import { Approver, Message } from '../model/approver';
import { Role } from '../model/role';

@Injectable()
export class SodsModelService {

    //SODS model map
    requisitionMap: any = [];
    sampleRequisition: Requisition = SAMPLEREQUISITION;
    customer: Customer;
    product: Product;
    user: UsfUser;
    reqId: string;

    constructor(private http: Http) {
        console.log("Initialize SODSModel Service");
        this.requisitionMap['9789'] = SAMPLEREQUISITION;
    }

    //SODS Function
    @ActionSubscriber(ActionEvents.FIND_REQ)
    private findReq(data: { reqId: string }): Event<any> | Promise<Event<any>> {

        let resultingEvent: Event<any> = null;

        var reqData = this.requisitionMap[data.reqId];
        if (reqData) {
            resultingEvent = new Event<any>('reqFound', this.sampleRequisition);
        } else {
            resultingEvent = new Event<any>('reqNotFound', {});
        }
        return resultingEvent;

    }

    @ActionSubscriber(ActionEvents.RETRIEVE_CUST)
    private retrieveCust(data: { id: string, division: string }): Event<any> | Promise<Event<any>> {
        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let url: string = environment.customerInquiryURL
            .concat('custNbr=' + data.id + '&div=' + data.division);

        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });

        return this.http.get(url, options).toPromise()
            .then((response: Response) => {
                let customer: Customer = ResponseMapper.mapCustomer(response.json());
                if (customer == null || customer == undefined)
                    return new Event<any>('custNotFound', {});
                else
                    return new Event<any>('custFound', customer);
            }, (err: Error) => {
                return new Event<any>('custNotFound', {});
            }).catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.RETRIEVE_CUST_SHIPTO)
    private retrieveCustforShipTo(data: { id: string, division: string }): Event<any> | Promise<Event<any>> {
        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let url: string = environment.customerInquiryURL
            .concat('custNbr=' + data.id + '&div=' + data.division);

        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });

        return this.http.get(url, options).toPromise()
            .then((response: Response) => {
                let customer: Customer = ResponseMapper.mapCustomer(response.json());
                if (customer == null || customer == undefined)
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_CUST_SHIPTO_FAIL, {});
                else
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_CUST_SHIPTO_SUCCESS, customer);
            }, (err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_CUST_SHIPTO_FAIL, {});
            }).catch(this.handleError);
    }

    //Product Related
    @ActionSubscriber(ActionEvents.VALIDATE_PRODUCT)
    private validateProduct(data: { productId: string, qty: string }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;

        this.product = this.searchProduct(data);

        if (this.product) {
            resultingEvent = new Event<any>('productValidated', this.product);
        } else {
            resultingEvent = new Event<any>('productNotValidated', {});
        }
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.LOAD_PRODUCT)
    private loadProduct(req: string): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let productList: Product[] = [];
        productList.push(SAMPLEProduct);
        productList.push(SAMPLEProduct_B);
        return new Event<any>('productLoadedSuccess', productList);
    }

    //Load Create Requisition Page
    @ActionSubscriber(ActionEvents.GENERATE_REQ_ID)
    private generateReqId(): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });

        return this.http.get(environment.generateReqIdURL, options)
            .toPromise()
            .then((res: Response) => {
                let body = res.json();
                return new Event<any>('requisitionIdGeneratedSuccess', body.reqId);
            })
            .catch(this.handleError);
    }

    //Loda Create Requisition Page - Retrieve TM
    @ActionSubscriber(ActionEvents.RETRIEVE_TM)
    private retrieveTM(searchId: string): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let username = localStorage.getItem('username');
        let password = localStorage.getItem('password');
        let body = JSON.stringify({ username, password, searchId });

        return this.http.post(environment.retrieveUserURL, body, { headers: contentHeaders })
            .toPromise()
            .then((res: Response) => {
                let responseBody = res.json();
                console.log("Emit TM FOUND Event");
                return new Event<any>(ModelChangeUpdateEvents.TM_FOUND, {responseBody, searchId});
            })
            .catch(this.handleError);
    }

    // Create Requisition Page - Retrieve TM
    @ActionSubscriber(ActionEvents.RETRIEVE_TM_2)
    private retrieveTM2(searchId: string): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let username = localStorage.getItem('username');
        let password = localStorage.getItem('password');
        let body = JSON.stringify({ username, password, searchId });

        return this.http.post(environment.retrieveUserURL, body, { headers: contentHeaders })
            .toPromise()
            .then((res: Response) => {
                let responseBody = res.json();
                return new Event<any>(ModelChangeUpdateEvents.TM_FOUND_2, responseBody);
            })
            .catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.RETRIEVE_TM_FROM_TANDEMID)
    private retrieveUSFTMFromTandemTM(tandemTMId: string): Event<any> | Promise<Event<any>>{
        let resultingEvent: Event<any> = null;
        let url: string = environment.retrieveUSFTMFromTandemIDURL
            .concat('/' + tandemTMId);

        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });

        return this.http.get(url, options).toPromise()
            .then((response: Response) => {
                //we do mapping here to return the response of tm information
                debugger
                console.log(response);
                let respBody = response.json();
                let tandemTM: TandemTM = ResponseMapper.mapTMInfo(respBody);
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_TM_FROM_TANDEMID_SUCCESS, tandemTM);
            }, (err: Error) => {
                debugger
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_TM_FROM_TANDEMID_FAIL, {});
            }).catch(this.handleError);
    
        
        //return null;
    }

    //Post Create Requisition Page - POST TM
    @ActionSubscriber(ActionEvents.POST_REQUISITION)
    private postRequisition(postBody: any): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        // headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });
        debugger
        return this.http.post(environment.postReqIdURL + '' + postBody.requisition.requisitionNumber, postBody, options)
            .toPromise()
            .then((res: Response) => {
                let body = res.json();
                console.log("Emit TM FOUND Event");
                return new Event<any>(ModelChangeUpdateEvents.POST_REQUISITION_SUCCESS, body);
            })
            .catch((err) => {
                const errorMessage = err.status === 0 ? 'Backend Service Down. Please Try again after some time' : err;
                return new Event<any>(ModelChangeUpdateEvents.POST_REQUISITION_FAIL, errorMessage);
            });
    }

    //Draft Create Requisition Page - POST TM
    @ActionSubscriber(ActionEvents.DRAFT_REQUISITION)
    private draftRequisition(postBody: any): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        // headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });

        return this.http.post(environment.draftReqIdURL + '' + postBody.requisition.requisitionNumber, postBody, options)
            .toPromise()
            .then((res: Response) => {
                let body = res.json();
                console.log("Emit TM FOUND Event");
                return new Event<any>(ModelChangeUpdateEvents.DRAFT_REQUISITION_SUCCESS, body);
            })
            .catch((err) => {
                const errorMessage = err.status === 0 ? 'Backend Service Down. Please Try again after some time' : err;
                return new Event<any>(ModelChangeUpdateEvents.DRAFT_REQUISITION_FAIL, errorMessage);
            });
    }

    @ActionSubscriber(ActionEvents.SEARCH_MARKET_ROLE)
    private searchMarketRole(market: string, role: string): Event<any> | Promise<Event<any>> {
        //place search logic here
        let resultingEvent: Event<any> = null;
        let resultingUsers: DivisionUser[] = [];
        resultingUsers.push(SAMPLEDivisionUserBuyer);
        resultingUsers.push(SAMPLEDivisionUserCA);
        return new Event<any>('MarketRoleFound', resultingUsers);
    }

    //Find Attachment here
    @ActionSubscriber(ActionEvents.FIND_ATTACHMENT)
    private findAttachment(): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let resultingAttachments: Attachment[] = [];
        resultingAttachments.push(SAMPLEATTACHMENT_A);
        resultingAttachments.push(SAMPLEATTACHMENT_B);
        return new Event<any>('attachmentFound', resultingAttachments);
    }

    //Header User Info
    @ActionSubscriber(ActionEvents.RETRIEVE_USER_INFO)
    private retrieveUserInfo(): Event<any> | Promise<Event<any>> {
        let resultingUser: UsfUser = new UsfUser();

        //let user = JSON.parse(JSON.parse(sessionStorage.getItem('user'))._body);
        let jsonResponse = JSON.parse(localStorage.getItem('user'));
        let user = JSON.parse(jsonResponse._body);

        resultingUser.userId = user.userId;
        resultingUser.firstName = user.firstName;
        resultingUser.lastName = user.lastName;
        resultingUser.email = user.email;
        resultingUser.phone = user.phone;

        return new Event<any>('userInfoFound', resultingUser);
    }

    //Retrieve Product Info
    @ActionSubscriber(ActionEvents.RETRIEVE_PRODUCT)
    private retrieveProduct(data: { searchType: string, div: string, prodNbr: string }): Event<any> | Promise<Event<any>> {

        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let url: string = '';
        if (data.searchType == 'Product(USF)') {
            url = environment.productRetrivalURL
                .concat('div=' + data.div + '&prodNbr=' + data.prodNbr + '&mfrProdNbr=-1');
        }
        if (data.searchType == 'Manufacturer Product') {
            url = environment.productRetrivalURL
                .concat('div=' + data.div + '&mfrProdNbr=' + data.prodNbr + '&prodNbr=-1');
        }

        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });

        return this.http.get(url, options).toPromise()
            .then((response: Response) => {
                let res = response.json();
                let resultProduct: Product = ResponseMapper.mapProduct(res.product[0]);
                if (resultProduct.description == '') {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_FAIL, 'Product is invalid. Please check the product number or product type');
                } else if (resultProduct.prodCnt > 1) {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_FAIL, 'More than one product is returned');
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_SUCCESS, resultProduct);
                }
            }, (err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_FAIL, 'Product is invalid. Please check the product number or product type');
            }).catch(this.handleError);
    }

    //Retrieve Product Info
    @ActionSubscriber(ActionEvents.RETRIEVE_PRODUCT_EDIT)
    private retrieveProductEdit(data: { searchType: string, div: string, prodNbr: string }): Event<any> | Promise<Event<any>> {

        let soapHeader: string = JSON.stringify(SAMPLEHEADER);
        let url: string = '';
        if (data.searchType == 'Product(USF)') {
            url = environment.productRetrivalURL
                .concat('div=' + data.div + '&prodNbr=' + data.prodNbr + '&mfrProdNbr=-1');
        }
        if (data.searchType == 'Manufacturer Product') {
            url = environment.productRetrivalURL
                .concat('div=' + data.div + '&mfrProdNbr=' + data.prodNbr + '&prodNbr=-1');
        }

        let token: string = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        headers.append('header', soapHeader);
        let options = new RequestOptions({ headers: headers });

        return this.http.get(url, options).toPromise()
            .then((response: Response) => {
                let res = response.json();
                let resultProduct: Product = ResponseMapper.mapProduct(res.product[0]);
                if (resultProduct.description == '') {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_EDIT_FAIL, 'Product is invalid. Please check the product number or product type');
                } else if (resultProduct.prodCnt > 1) {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_EDIT_FAIL, 'More than one product is returned');
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_EDIT_SUCCESS, resultProduct);
                }
            }, (err: Error) => {
                return new Event<any>(ModelChangeUpdateEvents.RETRIEVE_PRODUCT_EDIT_FAIL, 'Product is invalid. Please check the product number or product type');
            }).catch(this.handleError);
    }

    @ActionSubscriber(ActionEvents.DEPARTMENT_CHANGE)
    private changeDepartment(deptId: string): Event<any> {
        let resultingEvent: Event<any> = null;
        resultingEvent = new Event<any>(ModelChangeUpdateEvents.DEPARTMENT_CHANGE_SUCCESS, deptId);
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.REQ_CHANGE_EVT)
    private changeValue(value: any): Event<any> {
        let resultingEvent: Event<any> = null;
        resultingEvent = new Event<any>(ModelChangeUpdateEvents.REQ_CHANGE_EVT_SUCCESS, value);
        return resultingEvent;
    }



    @ActionSubscriber(ActionEvents.SHIPMENT_CHANGE)
    private changeShipment(data: any): Event<any> {
        let resultingEvent: Event<any> = null;
        resultingEvent = new Event<any>(ModelChangeUpdateEvents.SHIPMENT_CHANGE_SUCCESS, data);
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.CALENDAR_CHANGE)
    private changeCalendar(date: Date): Event<any> {
        let resultingEvent: Event<any> = null;
        resultingEvent = new Event<any>(ModelChangeUpdateEvents.CALENDAR_CHANGE_SUCCESS, date);
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.SHIPTO_CHANGE)
    private changeShipTo(data: any): Event<any> {
        let resultingEvent: Event<any> = null;
        resultingEvent = new Event<any>(ModelChangeUpdateEvents.SHIPTO_CHANGE_SUCCESS, data);
        return resultingEvent;
    }

    private searchProduct(data: { productId: string, qty: string }): Product {
        console.log('Product Id is' + data.productId);
        console.log('Product qty is' + data.qty);
        if (data.productId == SAMPLEProduct.productId && data.qty == SAMPLEProduct.qty) {
            return SAMPLEProduct;
        } else {
            return null;
        }
    }

    private handleError(error: any) {
        // In a real world app, we might use a remote logging infrastructure
        // We'd also dig deeper into the error to get a better message
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead
        return Promise.reject(errMsg);
    }

    /*
    *
    * Attachment Services
    *
    */

    /* 
        @param {string} requisitionId Requisition ID of current requisition
        @returns {array list} attachmentsList An array list of attachment details
    */
    @ActionSubscriber(ActionEvents.REQ_ATTACHMENT_DETAILS)
    private getAttachmentDetails(data: { requisitionId: string }): Event<any> | Promise<Event<any>> {
        console.log("Get attachment details: " + data.requisitionId);
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let attachmentsList = [];
        let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/details";

        return this.http.get(APIURL, options).toPromise().then(
            (res: Response) => {
                if (res[`_body`] == "") {
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_SUCCESS, {});
                } else {
                    let attachments = res.json();
                    attachments.forEach(element => {
                        let theAttachment = {};
                        theAttachment['fileName'] = element.fileName;
                        theAttachment['fileType'] = element.fileType;
                        theAttachment['fullName'] = element.fullName;
                        theAttachment['objectKey'] = element.objectKey;
                        theAttachment['dateUploaded'] = element.dateUploaded;
                        theAttachment['userId'] = element.userId;
                        attachmentsList.push(theAttachment);
                    });
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_SUCCESS, attachmentsList);
                }
            }
        ).catch(
            (error: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_FAIL, {});
            }
            );
    }

    /*
        @param {string} requisitionId Requisition ID of current requisition
        @param {ElementRef} fileRef Reference to the file element
        @returns {null}
    */
    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_UPLOAD)
    private uploadAttachments(requisitionId: string, fileRef: ElementRef, attachedFile: FormData): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let fullName = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).firstName + " " + JSON.parse(JSON.parse(localStorage.getItem('user'))._body).lastName;
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let APIURL = environment.requisitionAttachments + "/" + requisitionId + "/upload";
        let attachment = new FormData();
        let inputEl: HTMLInputElement = fileRef.nativeElement;
        let fileCount: number = inputEl.files.length;
        if (fileCount > 0) { // a file was selected
            for (let i = 0; i < fileCount; i++) {
                attachment.append("attachment", inputEl.files.item(i));
                attachment.append("fullName", fullName);
                attachment.append("userId", userId);
                let fileName = inputEl.files.item(i).name;
                inputEl.files.item(i).type;
                let currentDate = new Date();
                let creationDate = currentDate.toJSON();
            }
            this.http.put(APIURL, attachment, options).toPromise().then(
                (res: Response) => {
                    resultingEvent = new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_UPLOAD_SUCCESS, {});
                }
            ).catch(
                (error: Response) => {
                    resultingEvent = new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_UPLOAD_FAIL, "File could not be uploaded");
                }
                );
        }
        return resultingEvent;
    }

    /*
        @param {string} requisitionId Requisition ID of current requisition
        @param {string} objectKey Key of selected object
        @param {string} fileName Name of file
        @returns {null}
    */
    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_DOWNLOAD)
    private downloadAttachments(data: { requisitionId: string, objectKey: string, fileName: string }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/download" + "?objectKey=" + data.objectKey;
        return this.http.get(APIURL, { headers: headers, responseType: ResponseContentType.Blob }).toPromise().then(
            (res: Response) => {
                var blob = new Blob([res.blob()]);
                var fileNm = data.fileName;
                saveAs(blob, fileNm);
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                let errorBody = error.json();
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_FAIL, errorBody.message);
            }
            );

    }

    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_MULTI_DOWNLOAD)
    private downloadMultiAttachments(data: { requisitionId: string, multiDownloadList: Array<any> }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });

        data.multiDownloadList.forEach(element => {
            let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/download" + "?objectKey=" + element.objectKey;
            return this.http.get(APIURL, { headers: headers, responseType: ResponseContentType.Blob }).toPromise().then(
                (res: Response) => {
                    var blob = new Blob([res.blob()]);
                    var fileNm = element.name;
                    saveAs(blob, fileNm);
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_SUCCESS, {});
                }
            ).catch(
                (error: Response) => {
                    let errorBody = error.json();
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_FAIL, errorBody.message);
                }
                );
        })
        return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DOWNLOAD_SUCCESS, {});
    }

    /*
        @param {string} requisitionId Requisition ID of current requisition
        @param {string} objectKey Key of selected object
        @returns {null}
    */
    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_DELETE)
    private deleteAttachments(data: { requisitionId: string, objectKey: string }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/delete" + "?objectKey=" + data.objectKey + "&userId=" + userId;
        this.http.delete(APIURL, options).toPromise().then(
            (res: Response) => {
                resultingEvent = new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DELETE_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                let errorBody = error.json();
                resultingEvent = new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DELETE_FAIL, errorBody.message);
            }
            );
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_MULTI_DELETE)
    private deleteMultiAttachments(data: { requisitionId: string, multiDeleteList: Array<any> }): Event<any> | Promise<Event<any>> {
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        let keys: string;

        data.multiDeleteList.forEach(element => {
            keys = element.objectKey + "," + keys;
        })
        keys = keys.replace(/,\s*$/, "");
        let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/multiDelete" + "?objectKey=" + keys + "&userId=" + userId;
        this.http.delete(APIURL, options).toPromise().then(
            (res: Response) => {
                //return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_MULTI_DELETE_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_MULTI_DELETE_FAIL, "Failed to remove files, please try again");
            }
            );
        return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_MULTI_DELETE_SUCCESS, {});
    }

    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_SOFT_DELETE)
    private softDeleteAttachments(data: { requisitionId: string, attachmentsList: Array<any> }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });

        data.attachmentsList.forEach(element => {
            let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/delete" + "?objectKey=" + element.objectKey + "&userId=" + userId;
            this.http.delete(APIURL, options).toPromise().then(
                (res: Response) => {
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_SOFT_DELETE_SUCCESS, {});
                }
            ).catch(
                (error: Response) => {
                    let errorBody = error.json();
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_EDIT_FAIL, errorBody.message);
                });
        }
        );
        return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_SOFT_DELETE_SUCCESS, {});
    }

    @ActionSubscriber(ActionEvents.PROD_ATTACHMENT_DETAILS)
    private getProdAttachmentDetails(data: { requisitionId: string, attachmentKey: number }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let attachmentsList = [];
        let APIURL = environment.productAttachments + "/" + data.requisitionId + "/details?" + "sequenceId=" + data.attachmentKey;
        return this.http.get(APIURL, options).toPromise().then(
            (res: Response) => {
                if (res[`_body`] == "") {
                    return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS, {});
                } else {
                    let attachments = res.json();
                    attachments.forEach(element => {
                        let theAttachment = {};
                        theAttachment['fileName'] = element.fileName;
                        theAttachment['fileType'] = element.fileType;
                        theAttachment['fullName'] = element.fullName;
                        theAttachment['objectKey'] = element.objectKey;
                        theAttachment['dateUploaded'] = element.dateUploaded;
                        theAttachment['requisitionId'] = element.requisitionId;
                        attachmentsList.push(theAttachment);
                    });
                    return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS, attachmentsList);
                }
            }
        ).catch(
            (error: Response) => {
                return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_DETAILS_FAIL, {});
            }
            );
    }


    @ActionSubscriber(ActionEvents.PROD_ATTACHMENTS_DELETE)
    private deleteProdAttachments(data: { requisitionId: string, objectKey: string }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let APIURL = environment.productAttachments + "/" + data.requisitionId + "/delete" + "?objectKey=" + data.objectKey + "&userId = " + userId;

        this.http.delete(APIURL, options).toPromise().then(
            (res: Response) => {
                resultingEvent = new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DELETE_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                let errorBody = error.json();
                resultingEvent = new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DELETE_FAIL, errorBody.message);
            }
            );
        return resultingEvent;
    }

    @ActionSubscriber(ActionEvents.PROD_ATTACHMENTS_DOWNLOAD)
    private downloadProdAttachments(data: { requisitionId: string, objectKey: string, fileName: string, attachmentKey: number }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let APIURL = environment.productAttachments + "/" + data.requisitionId + "/download" + "?objectKey=" + data.objectKey;
        return this.http.get(APIURL, { headers: headers, responseType: ResponseContentType.Blob }).toPromise().then(
            (res: Response) => {
                var blob = new Blob([res.blob()]);
                var fileNm = data.fileName;
                saveAs(blob, fileNm);
                return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DOWNLOAD_SUCCESS, {});
            }
        ).catch(
            (error: Response) => {
                let errorBody = error.json();
                return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DOWNLOAD_FAIL, errorBody.message);
            }
            );
    }


    @ActionSubscriber(ActionEvents.PROD_ATTACHMENTS_MULTI_DOWNLOAD)
    private downloadMultiProdAttachments(data: { requisitionId: string, attachmentsList: Array<any>, seqId: string }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });

        data.attachmentsList.forEach(element => {
            let APIURL = environment.productAttachments + "/" + data.requisitionId + "/download" + "?objectKey=" + element.objectKey;
            console.log(APIURL);
            return this.http.get(APIURL, { headers: headers, responseType: ResponseContentType.Blob }).toPromise().then(
                (res: Response) => {
                    var blob = new Blob([res.blob()]);
                    var fileNm = element.fileName;
                    saveAs(blob, fileNm);
                }
            ).catch(
                (error: Response) => {
                    let errorBody = error.json();
                    return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DOWNLOAD_FAIL, errorBody.message);
                });
        }
        );

        return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACH_DOWNLOAD_SUCCESS, {});
    }

    @ActionSubscriber(ActionEvents.REQ_ATTACHMENTS_EDIT)
    private editAttachments(data: { requisitionId: string, fileType: string, attachmentsList: Array<any> }): Event<any> | Promise<Event<any>> {
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        data.attachmentsList.forEach(element => {
            let APIURL = environment.requisitionAttachments + "/" + data.requisitionId + "/update" + "?objectKey=" + element.objectKey + "&fileType=" + data.fileType;
            this.http.put(APIURL, null, options).toPromise().then(
                (res: Response) => {
                }
            ).catch(
                (error: Response) => {
                    let errorBody = error.json();
                    return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_EDIT_FAIL, "File(s) could not be attached");
                });
        }
        );
        return new Event<any>(ModelChangeUpdateEvents.REQ_ATTACH_EDIT_SUCCESS, {});
    }

    @ActionSubscriber(ActionEvents.PROD_ATTACHMENTS_MULTI_DELETE)
    private prodDeleteMultiAttachments(data: { requisitionId: string, attachmentsList: Array<any> }): Event<any> | Promise<Event<any>> {
        console.log("Inside sodsmodelservice deleteMultiAttachments");
        let resultingEvent: Event<any> = null;
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let userId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
        data.attachmentsList.forEach(element => {
            let APIURL = environment.productAttachments + "/" + data.requisitionId + "/delete" + "?objectKey=" + element.objectKey + "&userId=" + userId;
            console.log(APIURL);
            this.http.delete(APIURL, options).toPromise().then(
                (res: Response) => {
                    console.log("Delete Multiple Attachments Response: " + res);
                    resultingEvent = new Event<any>(ModelChangeUpdateEvents.PROD_ATTACHMENTS_MULTI_DELETE_SUCCESS, {});
                }
            ).catch(
                (error: Response) => {
                    console.log("Delete Multiple Attachments Error: " + error);
                    resultingEvent = new Event<any>(ModelChangeUpdateEvents.PROD_ATTACHMENTS_MULTI_DELETE_FAIL, {});
                }
                );
            return resultingEvent;
        })
        return new Event<any>(ModelChangeUpdateEvents.PROD_ATTACHMENTS_MULTI_DELETE_SUCCESS, {});
    }

    @ActionSubscriber(ActionEvents.DELETE_REQ)
    private deleteRequisition(reqId: string): Event<any> | Promise<Event<any>>{
        let token = JSON.parse(localStorage.getItem('token')).value;
        let headers = new Headers();
        headers.append('Authorization', `Bearer ${token}`);
        let options = new RequestOptions({ headers: headers });
        let url: string = environment.deleteRequisitionURL.concat('/' + reqId);

        return this.http.delete(url, options).toPromise()
            .then((response: Response) => {
                //we do mapping here to return the response of tm information
                debugger
                let respBody = response.json();
                return new Event<any>(ModelChangeUpdateEvents.DELETE_REQ_SUCCESS, {});
            }, (err: Response) => {
                debugger
                return new Event<any>(ModelChangeUpdateEvents.DELETE_REQ_FAIL, err);
            }).catch(this.handleError);
        }

    /* For Market Role Manager Search Bar */
    @ActionSubscriber(ActionEvents.GET_DIVISIONS_FOR_ROLE_SEARCH)
    private getDivisionsForRoleSearch(data: any): Event<any> | Promise<Event<any>> {
        const limit = data.limit;
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        const resultingEvent = null;
        console.log("Calling API");

        return this.http.get(environment.getDivisionsURL, options)
            .toPromise()
            .then((res: Response) => {
                const response = res.json();
                if (response) {
                    const responseDivisions = response.divisionList;
                    const divisions = new Array<Division>();
                    responseDivisions.forEach((row) => {
                        const division = new Division();
                        division.city = row.city;
                        division.divisionCode = row.divisionCode;
                        division.divisionName = row.divisionName;
                        division.divisionNumber = row.divisionNumber;
                        division.region = row.region;
                        division.state = row.state;
                        division.status = row.status;
                        divisions.push(division);
                    });
                    return new Event<any>(ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_SUCCESS, divisions);
                } else {
                    return new Event<any>(ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_FAIL, response);
                }
            })
    }

    @ActionSubscriber(ActionEvents.GET_APPROVERS_FOR_MARKET)
    private getRolesForMarket(data: string): Event<any> | Promise<Event<any>> {
        const divNbr = data['divisionNumber'] || '';
        const token = JSON.parse(localStorage.getItem('token')).value;
        const headers = new Headers({ 'Accept': 'application/json' });
        headers.append('Authorization', `Bearer ${token}`);
        const options = new RequestOptions({ headers: headers });
        const resultingEvent = null;
        const url:string = environment.marketRoleManagerURL.concat('?division=' + divNbr).concat('&applicationID=1');
        console.log("Calling API");

        return this.http.get(url, options)
            .toPromise()
            .then((res: Response) => {
                const response = res.json();
                const approvers = response.approver;
                const formattedResponse = [];
                if (response) {
                    if(response['allOOO'] === 'false') {
                        approvers.forEach((row) => {
                            const approver = new Approver();
                            approver.action = row.action;
                            approver.applicationID = row.applicationID;
                            approver.designatedID = row.designatedID;
                            approver.division = row.division;
                            approver.email = row.email;
                            approver.firstName = row.firstName;
                            approver.lastName = row.lastName;
                            approver.level = row.level;
                            approver.outofOffice = row.outofOffice;
                            approver.returnDate = row.returnDate;
                            approver.userId = row.userId;
                            approver.roleID = row.roleID;
                            approver.roleName = Role.getRoleName(approver.roleID);
                            approver.messages =[];
                            row.messages.forEach((message) => {
                                const approverMessage = new Message();
                                approverMessage.type = message.type;
                                approverMessage.desc = message.desc;
                                approver.messages.push(message);
                            });
                            formattedResponse.push(approver);
                        });

                        return new Event<any>(ModelChangeUpdateEvents.APPROVERS_FOR_MARKET_SUCCESS,
                            {'data': true, 'approvers': formattedResponse});
                    } else {
                        return new Event<any>(ModelChangeUpdateEvents.APPROVERS_FOR_MARKET_FAIL, {'data': false});
                    }
                }
            })
            .catch(this.handleError);
    }

}
