import { Component, OnInit } from '@angular/core';
import { ActionDispatcherService, ModelPresenterService } from 'usf-sam';
import { SodsModelService } from './demomodel/sodsmodel.service';

import { ActionEvents } from './events/action-events';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit  {

  title = 'SODS Demo!';

  constructor( readonly actionDispatcher: ActionDispatcherService, readonly modelPresenter: ModelPresenterService,
               readonly sodsmodel: SodsModelService){
  }

  ngOnInit(){
    
    console.log("call ng On Init");

    this.modelPresenter.registerEventsForModel(this.sodsmodel);




  }


}
