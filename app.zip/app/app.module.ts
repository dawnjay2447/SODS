import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule , ReactiveFormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
//Import the service here
import { ActionDispatcherService, ModelPresenterService, EventTypeRegistryService, StateRepresentationRendererService } from 'usf-sam';

//Login Component
import { LoginComponent } from './democomponents/login/login.component';
import { LogOffComponent } from './democomponents/login/logoff.component';

//Header Component
import { HeaderComponent } from './democomponents/header/header.component'

//Routing
import { appRoutingProviders, routing } from './app.routes';
import { AuthGuard } from './democomponents/util/auth.guard';

//Register the SODSModelService
import { SodsModelService } from './demomodel/sodsmodel.service';
import { AuthenticationService } from './service/authentication.service';
import { FilenotfoundComponent } from './democomponents/login/filenotfound.component';
import { OutofofficeComponent } from './democomponents/outofoffice/outofoffice.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LogOffComponent,
    FilenotfoundComponent,
    OutofofficeComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    routing,
     SharedModule,
    BrowserAnimationsModule
  ],
  providers: [
    ActionDispatcherService, 
    ModelPresenterService, 
    SodsModelService,
    EventTypeRegistryService,
    StateRepresentationRendererService,
    AuthenticationService,
    AuthGuard],
  bootstrap: [AppComponent]
})

export class AppModule { }