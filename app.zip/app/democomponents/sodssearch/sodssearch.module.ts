import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from  '../../shared/shared.module';
import { RouterModule } from '@angular/router';
import { SodssearchComponent } from '../sodssearch/sodssearch.component';

import { routing } from './sodssearch.routes';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    routing
  ],
  declarations: [
    SodssearchComponent
  ]
})
export class SodssearchModule { }
