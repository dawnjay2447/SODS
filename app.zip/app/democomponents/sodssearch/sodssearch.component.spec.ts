import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SodssearchComponent } from './sodssearch.component';

describe('SodssearchComponent', () => {
  let component: SodssearchComponent;
  let fixture: ComponentFixture<SodssearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SodssearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SodssearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
