import { Imports } from 'aws-sdk/clients/cloudformation';
import { Component } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { SAMPLEUSER } from '../../model/usfuser';
import { HeaderComponent } from './header.component';

@Component({
  template: ''
})
class DummyComponent {
}

fdescribe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderComponent, DummyComponent  ],
      imports: [RouterTestingModule.withRoutes([
        { path: 'search', component: DummyComponent }
      ])]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('should render username', () => {
    component.renderUsername(SAMPLEUSER);
    expect(component.username).toBe("Name Sample");
  });
});
