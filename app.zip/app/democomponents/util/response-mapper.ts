import { Customer } from '../../model/customer';
import { Product, Vendor } from '../../model/product';
import { TandemTM } from '../../model/tandemTM';

export class ResponseMapper {

    static mapCustomer(data: any): Customer {
        let customer: Customer = new Customer();
        customer.id = data.custNbr;
        customer.division = data.div;
        customer.name = data.custNm;
        customer.address1 = data.addr.addr1;
        customer.address2 = data.addr.addr2;
        customer.city = data.addr.cty;
        customer.state = data.addr.ste;
        customer.zip = data.addr.zip;
        customer.phone = data.phone.telNbr;
        customer.estimatedOrderAmt = '321.12';
        customer.confidenceCode = data.creditCd;
        customer.creditCheckStatus = 'true';
        customer.tmId = data.rte.tmId;
        customer.tmName = 'sodsus02, SharedAcct';
        customer.tmEmail = 'Shared.sodsus02@foodfite.com';
        customer.deptOptions = this.buildOptions(data.dept || []);
        customer.custType = data.custTyp;
        return customer;
    }

    static mapProduct(data: any): Product{
        let product: Product = new Product();
        let vendor : Vendor = new Vendor();
        product.vendor = vendor;
        product.description = data.desc;
        product.productId = data.prodNbr;
        product.mfrId = data.mfrProdNbr;
        product.distSts = data.distSts;
        product.label = data.label;
        product.priceUOM = data.priceUOM;
        product.packSize = data.slsPkSize;
        product.netWeight = data.netWght;
        product.salesUOM = data.slsUOM;
        product.vendor.vendorId = data.primVndrDtl.vndrNbr;
        product.vendor.vendorName = data.primVndrDtl.vndrNm;
        product.prodCnt = data.prodCnt;
        //add converter
        product.convFctr = data.convFctr;
        product.ntnlSts = data.ntnlSts;
        product.prodAttchd = data.prodAttchd;
        return product;
    }

    static mapTMInfo(data: any): TandemTM{
        let tandemTM: TandemTM = new TandemTM();
        tandemTM.routeToDivision = data.routeToDivision;
        tandemTM.routeToDivisionCode = data.routeToDivisionCode;
        tandemTM.routeToDivisionSystem = data.routeToDivisionSystem;
        tandemTM.routeToDivisionTimezone = data.routeToDivisionTimezone;
        tandemTM.routeToDSMID = data.routeToDSMID;
        tandemTM.routeToFMID = data.routeToFMID;
        tandemTM.routeToRSMID = data.routeToRSMID;
        tandemTM.routeToVPID = data.routeToVPID;
        tandemTM.status = data.status;
        tandemTM.statusDescription = data.statusDescription;
        tandemTM.tmnetworkID = data.tmnetworkID;
        tandemTM.tmparentDivision = data.tmparentDivision;
        return tandemTM;
    }

    private static buildOptions(dept: any): string[] {
        let optionList: string[] = [];

        for(let i = 0; i < dept.length; i++) {
            let entry = dept[i];
            let department = entry.dptNbr.concat('-'.concat(entry.dptNm));
            optionList.push(department);
        }
        return optionList;
    }
}