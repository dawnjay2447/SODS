import { Component, OnInit, Input, Output, EventEmitter, HostBinding, ViewEncapsulation, ViewChild } from '@angular/core';
import {AutoCompleteModule} from 'primeng/primeng';

@Component({
  selector: 'sods-autocomplete',
  templateUrl: './autoComplete.component.html',
  styleUrls: ['./autoComplete.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AutoCompleteComponent implements OnInit {

  isVisible: boolean = false;
  @Input() value: string;
  @Input() data: any[];
  @Input() error: boolean;
  @Output() searchData = new EventEmitter();
  @Output() errorEmitter = new EventEmitter();
  results: any[] = [];

  constructor() { }

  ngOnInit() {
  }

  search(event) {
        this.results = [];
        for(let i = 0; i < this.data.length; i++) {
            let brand = this.data[i];
            if(brand.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
                this.results.push(brand);
            }
        }
          //this.searchData.emit(event.query);
    }
  
  selectItem(event) {
    console.log(this.value);
    this.searchData.emit(this.value);
  }  

}
