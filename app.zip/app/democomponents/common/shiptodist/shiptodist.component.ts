import {Component, OnInit, ViewChild} from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';



@Component({
    selector: 'app-ship-to-dist',
    templateUrl: './shiptodist.component.html',
    styleUrls: ['./shiptodist.component.css']
})

export class ShiptodistComponent implements OnInit{

    @ViewChild('AddShipToLocation')AddShipToLocationModal: Modal;

    ngOnInit(){

    }

    addShipToLocation(){
        this.AddShipToLocationModal.open();
    }

}