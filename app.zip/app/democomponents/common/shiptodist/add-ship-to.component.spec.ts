import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddShipToComponent } from './add-ship-to.component';

describe('AddShipToComponent', () => {
  let component: AddShipToComponent;
  let fixture: ComponentFixture<AddShipToComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddShipToComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddShipToComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
