import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  public retrieveSuccess = false;
  public isTM = false;
  public isRequestor = false;
  public tmTitle = false;
  public isPhoneValid : boolean = true;
  public isEmailValid: boolean = true;
  name: string;
  networkId: string;
  phone: string;
  email: string;
  addlPhone: string;
  addlEmail: string;
  constructor() {
    this.name = "---";
    this.phone = "---";
    this.email = "---";
  }
  ngOnInit() { }
  checkIfAddlEmailValid() {	  
	  if(this.validateEmail(this.addlEmail)) {
			this.isEmailValid = true;
	  } else {
			this.isEmailValid = false;
	  }
	}
	
	checkIfAddlPhoneValid() {
    if(this.validatePhone(this.addlPhone)) {
      this.isPhoneValid = true;
    } else { 
      this.isPhoneValid = false; 
    }
  }
  validateEmail(emailAddress: string){
		if(emailAddress == null || emailAddress == undefined || emailAddress.trim() == '') return true;
		let EMAIL_REGEXP = /^\w+([.-]\w+)*@\w+([.-]\w+)*(\.\w{2,3})+$/
    return EMAIL_REGEXP.test(emailAddress);
	}
	
	validatePhone(phone: string){
		if(phone == null || phone == undefined || phone.trim() == '') return true;
		let PHONE_REGEXP = /^[0-9]{10,12}$/
		return PHONE_REGEXP.test(phone);
	}
}