import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { SharedModule } from './../../../shared/shared.module';

import { EditCustomerComponent } from './edit-customer.component';

fdescribe('EditCustomerComponent', () => {
  let component: EditCustomerComponent;
  let fixture: ComponentFixture<EditCustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [SharedModule],
      declarations: []
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('intialize the component', () => {
    //set options
    component.marketOptions = [{divisionNumber: '12345'}];
    component.ngOnInit();
    //check value
    expect(component.defaultMarket).toBe('12345');
    expect(component.selectedMarket).toBe('12345');
  });

  it('should set the selected Market', () => {
    component.onMarketSelection('12345');
    expect(component.selectedMarket).toBe('12345');
  });
});
