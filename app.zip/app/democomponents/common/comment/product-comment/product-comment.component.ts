import { Component, OnInit } from '@angular/core';
import { Comment, SAMPLECommentA, SAMPLECommentB } from '../../../../model/comment';

@Component({
  selector: 'sods-product-comment',
  templateUrl: './product-comment.component.html',
  styleUrls: ['./product-comment.component.css']
})
export class ProductCommentComponent implements OnInit {

  public comments: Array<Comment> = [];
  public newAddFlag: boolean = false;
  public productSeq: number;
  public newAddedCount: number = 0;

  private textareaLength: number = 1000;
  maxIncidentDescriptionLength: any = 1000;
  //validation for comment
  public commentErr : boolean = false;

  constructor() { }

  ngOnInit() {

  }

  addComment(){
    //check if the comment added previously is empty or not
    if(this.newAddedCount > 0){
      if(this.comments[0].commentText == null || this.comments[0].commentText == undefined || this.comments[0].commentText.trim() == ''){
        this.commentErr = true;
      }
    }
    if(!this.commentErr){
      this.newAddedCount += 1;
      this.comments.reverse();
      let newComment : Comment = new Comment();
      newComment.name = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).displayName;
      newComment.timeStamp = new Date();
      newComment.netWorkId = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
      newComment.commentText = '';
      this.commentErr = false;
      this.newAddFlag = true;
      this.comments.push(newComment);
      this.comments.reverse();
    }
  }


  checkComment(comment: Comment){
    if(comment.commentText == null || comment.commentText == undefined || comment.commentText.trim() == ''){
      this.commentErr = true;
    }else{
      comment.commentText = comment.commentText.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
      this.commentErr = false;
    }
  }

  autogrow(){
    let textArea = document.getElementById("area");       
    textArea.style.overflow = 'hidden';
    textArea.style.height = '50px';
    textArea.style.height = textArea.scrollHeight + 'px';
  }
}
