// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { SharedModule } from './../../../shared/shared.module';
// import { EditExistingProductComponent } from './edit-existing-product.component';
// import { SAMPLEProduct, SAMPLEVendor } from '../../../model/product';
// import { SAMPLECommentA} from '../../../model/comment';
// import { SAMPLECUSTOMER } from '../../../model/customer';

// fdescribe('EditExistingProductComponent', () => {
//   let component: EditExistingProductComponent;
//   let fixture: ComponentFixture<EditExistingProductComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [],
//       imports: [BrowserAnimationsModule, SharedModule]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(EditExistingProductComponent);
//     component = fixture.componentInstance;
//     component.actionDispatcherService.dispatch = () => {};
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should onSearchTypeSelection', () => {
//     component.onSearchTypeSelection('123');
//     expect(component.selectedSearchType).toBe('123');
//   });

//   it('should retrieveProduct', () => {
//     component.retrieveProduct();
//   });

//   it('should renderCustFound', () => {
//     component.renderCustFound(SAMPLECUSTOMER);
//   });

//   it('should renderProductFound', () => {
//     component.renderProductFound(SAMPLEProduct);
//   });

//   it('should renderProductNotFound', () => {
//     component.renderProductNotFound('error');
//     expect(component.product_not_found_error).toBeTruthy();
//   });

//   it('should onDateSelectionDone', () => {
//     component.onDateSelectionDone('123');
//     expect(component.product.eta).toBe('123');
//   });

//   it('should onErrorHandler', () => {
//     component.onErrorHandler('error');
//     expect(component.date_selection_error).toBeTruthy();

//     component.onErrorHandler('errojkr');
//     expect(component.date_selection_error).toBeFalsy();
//   });

//   it('should checkSellPrice', () => {
//     component.product = SAMPLEProduct;
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(false);

//     component.product.sellPrice = '';
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(false);

//     //validate quote
//     component.product.sellPrice = undefined;
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(false);


//     //validate quote
//     component.product.sellPrice = 'sdasdasd';
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(true);

//     //validate quote
//     component.product.sellPrice = '1';
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(false);
//     expect(component.product.sellPrice).toBe('1.00');

//     //validate quote
//     component.product.sellPrice = '.1';
//     component.checkSellPrice();
//     expect(component.sellPrice_number_error).toBe(false);
//     expect(component.product.sellPrice).toBe('0.1');

//     // Validate null value
//     expect(component.validateQuotePrice(null)).toBe(true);

//   });

//   it('should checkHandlingPrice', () => {
//     component.product = SAMPLEProduct;
//     component.product.handling = '1234';
//     component.checkHandlingPrice();
//     expect(component.handling_number_error).toBe(false);
    
//     //empty value
//     component.product.handling = '';
//     component.checkHandlingPrice();
//     expect(component.handling_number_error).toBe(false);

//     //empty value
//     component.product.handling = undefined;
//     component.checkHandlingPrice();
//     expect(component.handling_number_error).toBe(false);


//     //empty value
//     component.product.handling = ' ';
//     component.checkHandlingPrice();
//     expect(component.handling_number_error).toBe(false);

//     //validate quote
//     component.product.handling = 'sdasdasd';
//     component.checkHandlingPrice();
//     expect(component.handling_number_error).toBe(true);

//     //validate quote
//     component.product.handling = '.1';
//     component.checkHandlingPrice();
//     expect(component.handling_number_error).toBe(false);
//     expect(component.product.handling).toBe('0.1');

    
//   });

//   it('should checkNumberFormatforQty', () => {
//     component.product = SAMPLEProduct;
//     component.checkNumberFormatforQty();
//     expect(component.qty_require_error).toBe(true);
//     expect(component.qty_number_error).toBe(false);
    
//     //empty value
//     component.product.qty = 'asdasd';
//     component.checkNumberFormatforQty();
//     expect(component.qty_require_error).toBe(false);
//     expect(component.qty_number_error).toBe(true);

//     //validate number
//     component.product.qty = '0';
//     component.checkNumberFormatforQty();
//     expect(component.qty_require_error).toBe(false);
//     expect(component.qty_number_error).toBe(false);

//     //empty value
//     component.product.qty = ' ';
//     component.checkNumberFormatforQty();
//     expect(component.qty_require_error).toBe(true);
//     expect(component.qty_number_error).toBe(false);
//   });

// });
