// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { SharedModule } from './../../../shared/shared.module';
// import { UploadProductComponent } from './upload-product.component';

// fdescribe('UploadProductComponent', () => {
//   let component: UploadProductComponent;
//   let fixture: ComponentFixture<UploadProductComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [],
//       imports: [SharedModule]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(UploadProductComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
