// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { SharedModule } from './../../../shared/shared.module';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { ProductComponent } from './product.component';
// import { SAMPLEProduct, SAMPLEVendor } from '../../../model/product';
// import { SAMPLECommentA} from '../../../model/comment';
// import { SAMPLECUSTOMER } from '../../../model/customer';

// fdescribe('ProductComponent', () => {
//   let component: ProductComponent;
//   let fixture: ComponentFixture<ProductComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [],
//       imports: [BrowserAnimationsModule, SharedModule]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ProductComponent);
//     component = fixture.componentInstance;
//     component.actionDispatcherService.dispatch = () => {};
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   it('should openAddNew', () => {
//     component.openAddNew();
//   });

//   it('should closeAddNew', () => {
//     component.productNewAddModal.close = () => {};
//     component.productAttachmentModal.close = () => {};
//     component.closeAddNew();
//     component.cancelAddNew();
//   });

//   it('should openAddExisting', () => {
//     component.openAddExisting();
//   });

//   it('should closeAddExisting', () => {
//     component.productExistingAddModal.close = () => {};
//     component.productAttachmentModal.close = () => {};
//     component.closeAddExisting();
//     component.cancelAddExisting();
//   });

//   it('should addAndSave', () => {
//     component.products = [SAMPLEProduct];
//     component.products[0].seq = 1234;
//     component.addExistingProduct.product = SAMPLEProduct;
//     component.addAndSave();
//   });

//   it('should addExisting', () => {
//     component.products = [SAMPLEProduct];
//     component.products[0].seq = 1234;
//     component.addExistingProduct.product = SAMPLEProduct;
//     component.addExisting();
//   });

//   it('should addNew', () => {
//     component.addNew();
//   });

//   it('should addExisting', () => {
//     component.addExisting();
//   });

//   it('should renderCustFound', () => {
//     component.renderCustFound();
//     expect(component.retrieveCustSuccss).toBeTruthy();
//   });
//   it('should renderProductFound', () => {
//     component.renderProductFound();
//     expect(component.retrieveProductSuccess).toBeTruthy();
//   });

//   it('should renderProductNotFound', () => {
//     component.renderProductNotFound();
//     expect(component.retrieveProductSuccess).toBeFalsy();
//   });

//   it('should renderCalendarChangeSuccess', () => {
//     component.products = [SAMPLEProduct];
//     component.renderCalendarChangeSuccess(new Date());
//   });

//   it('should dataHasDuplicateValue', () => {
//     //failuer case
//     component.products = [SAMPLEProduct];
//     expect(component.dataHasDuplicateValue(SAMPLEProduct)).toBe(true);

//     //success case
//     component.products = [SAMPLEProduct];
//     component.products[0].seq = 12345566;
//     expect(component.dataHasDuplicateValue(SAMPLEProduct)).toBe(true);
//   });

//   it('should dataHasDuplicateValueforEdit', () => {
//     component.products = [SAMPLEProduct];
//     expect(component.dataHasDuplicateValueforEdit(SAMPLEProduct)).toBe(false);

//     component.products = [SAMPLEProduct];
//     component.products[0].seq = 1234;
//     expect(component.dataHasDuplicateValueforEdit(SAMPLEProduct)).toBe(false);
//   });

//   it('should closeRemove', () => {
//     component.removeLocationModal.close = () => {};
//     component.closeRemove();
//   });

//   it('should removeProduct', () => {

//     component.removeProduct(SAMPLEProduct);
//     expect(component.delProduct).toBe(SAMPLEProduct);
//   });

//   it('should remove', () => {
//     component.products = [SAMPLEProduct];
//     component.delProduct = SAMPLEProduct;
//     component.remove();
//     expect(component.products.length).toBe(0);
//   });

//   it('should openProductAttachment', () => {
//     component.openProductAttachment('');
//   });

  

//   it('should openAddComment', () => {
//     component.openAddComment(SAMPLEProduct);
//   });

//   it('should closeComment', () => {
//     component.addProductCommentModal.close = () => {};
//     component.closeComment();
    
//     //true
//     component.productComments.newAddFlag = true;
//     component.closeComment();
//   });

//   it('should saveComment', () => {
//     component.addProductCommentModal.close = () => {};
//     component.productComments.newAddFlag = true;
//     component.saveComment();
//   });

//   it('should saveComment', () => {
//     component.addProductCommentModal.close = () => {};
//     component.saveComment();
//   });

//   it('should editProduct', () => {
//     const k_editProduct = SAMPLEProduct;
//     component.editProduct(SAMPLEProduct);
//     k_editProduct.isNew = true;
//     component.editProduct(k_editProduct);
//   });

//   it('should editNewProduct', () => {
//     component.products = [SAMPLEProduct];
//     component.editProductNewModal.close = () => {};
//     component.editNewProductComponent.product = SAMPLEProduct;
//     component.editNewProduct();
//   });
//   //cancelEditNewProduct
//   it('should cancelEditNewProduct', () => {
//     component.products = [SAMPLEProduct];
//     component.editProductNewModal.close = () => {};
//     component.cancelEditNewProduct();
//   });

//   it('should editExistingProduct', () => {
//     component.products = [SAMPLEProduct];
//     component.editProductExistingModal.close = () => {};
//     component.editExistingProductComponent.product = SAMPLEProduct;
//     component.editExistingProduct();
//   });

//   it('should cancelEditExistingProduct', () => {
//     component.products = [SAMPLEProduct];
//     component.editProductExistingModal.close = () => {};
//     component.cancelEditExistingProduct();
//   });
  
//   //dataHasDuplicateValue

// });
