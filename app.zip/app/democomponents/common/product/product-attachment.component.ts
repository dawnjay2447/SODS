import { Attachment } from './../../../model/attachment';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Modal, ModalModule } from 'ngx-modal';

import { BaseComponent } from '../../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from "../../../events/action-events";
import { Product } from '../../../model/product';

@Component({
  selector: 'app-product-attachment',
  templateUrl: './product-attachment.component.html',
  styleUrls: ['./product-attachment.component.css']
})
export class ProductAttachmentComponent extends BaseComponent implements OnInit {

  public seqId:number;
  public requisitionId:number;
  public attachmentKey:number;
  actionCompleted:boolean = true;
  public actionFailed = false;
  public product: Product;
  public attachmentsList:Array<Attachment> = [];
  errorMsg: string;

  constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {

    super(stateRepresentationRendererService);
    let mapping: any = [];
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_SUCCESS] = (data: string[]) => {    this.renderAttachmentDetails(data);  }
    mapping[ModelChangeUpdateEvents.PROD_ATTACH_DETAILS_FAIL] = () => {this.renderNoAttachmentDetails()}
    super.registerStateChangeEvents(mapping); 
}

ngOnInit() {
  this.attachmentsList = [];
  
  let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENT_DETAILS, {requisitionId: this.requisitionId, attachmentKey:this.attachmentKey});
  this.actionDispatcherService.dispatch(event);
}

renderAttachmentDetails(data) {
  console.log("Rendering Attachment Details: " + data[0].fileName);
  this.attachmentsList = data;
}

  renderNoAttachmentDetails() {
    this.actionCompleted = true;
    console.log("No attachment details found for this requisition ID");
  }

  renderAttachmentDownloaded() {
    this.actionCompleted = true;
    console.log("Attachment downloaded successfully!");
  }

  downloadAttachments(requisitionId, fileName, objectKey, attachmentKey) {
    this.actionCompleted = false;
    console.log("Req Id: " + requisitionId + " File Name: " + fileName + " ObjectKey: " + objectKey);
    let event = this.actionDispatcherService.generateEvent(ActionEvents.PROD_ATTACHMENTS_DOWNLOAD, {requisitionId: requisitionId, objectKey: objectKey, fileName: fileName, attachmentKey: attachmentKey});
    this.actionDispatcherService.dispatch(event);
  }

  renderError(error: any) {
    this.actionCompleted = true;
    console.log(error.statusText);
    this.errorMsg = error.statusText;
    this.actionFailed = true;
  }


}
