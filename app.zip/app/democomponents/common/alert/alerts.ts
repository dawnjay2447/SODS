export const ALERTS = {
    'success': {
        'role-validation-success': 'Validation successful.  All roles are active.'
    },
    'error': {
        'level-one-required': 'Level 1 is required.'
    }

};
