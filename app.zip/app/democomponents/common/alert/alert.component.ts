import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { ALERTS } from './alerts';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit, OnChanges{

  @Input() alertType: string;
  @Input() alertMessage: string;
  @Input() interval: number;

  message: string;

  constructor() {
  }

  ngOnInit() {
    this.message = ALERTS[this.alertType][this.alertMessage];
  }

  ngDoCheck() {

  }

  ngOnChanges(changes: SimpleChanges): void {

  }
}
