import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditFileComponent } from './edit-file.component';

fdescribe('EditFileComponent', () => {
  let component: EditFileComponent;
  let fixture: ComponentFixture<EditFileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditFileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should select correct boolean values', () => {
    component.onFileTypeSelection('nothing');
    component.selectFileType = 'Other';
    expect(component.other_require_error).toBeFalsy;
    expect(component.invalid_format).toBeFalsy;
    expect(component.valid_format_error).toBeFalsy;
    expect(component.otherSelected).toBeTruthy;
    expect(component.file_type_error).toBeFalsy;

    component.selectFileType = '';
    expect(component.other_require_error).toBeFalsy;
    expect(component.invalid_format).toBeFalsy;
    expect(component.valid_format_error).toBeFalsy;
    expect(component.otherSelected).toBeFalsy;
    expect(component.file_type_error).toBeTruthy;

    component.selectFileType = null;
    expect(component.other_require_error).toBeFalsy;
    expect(component.invalid_format).toBeFalsy;
    expect(component.valid_format_error).toBeFalsy;
    expect(component.otherSelected).toBeFalsy;
    expect(component.file_type_error).toBeFalsy;
  })

});
