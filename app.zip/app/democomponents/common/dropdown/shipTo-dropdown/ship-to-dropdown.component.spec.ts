import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShipToDropdownComponent } from './ship-to-dropdown.component';

describe('ShipToDropdownComponent', () => {
  let component: ShipToDropdownComponent;
  let fixture: ComponentFixture<ShipToDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShipToDropdownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShipToDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
