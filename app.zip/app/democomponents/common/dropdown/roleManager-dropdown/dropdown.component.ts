import { Component, OnInit, Input, Output, OnChanges, SimpleChanges, EventEmitter, HostBinding, HostListener, ElementRef } from '@angular/core';

@Component({
  selector: 'app-roleman-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class RoleManDropdownComponent {

  isVisible: boolean = false;
  @Input() selectedOption: string;
  @Input() options: string[];
  @Input() smBtn: boolean;
  @Input() width: string;
  @Input() height: string;
  @Output() selectionDone = new EventEmitter();

  constructor(private el: ElementRef) { }

  @HostListener('click')
  @HostListener('document:click', ['$event'])
    handleClick(ev: Event) {
        // console.log(this.el)
        if (ev && !this.el.nativeElement.contains(ev.target)) {
            this.isVisible = false;
        }
    }

  @HostListener('window:keyup', ['$event']) 
    handleKeyup(event) {
        if (event.code === 'Tab') {
            this.isVisible = false;
        }
    }

  toggleDropDown(){
      this.isVisible = !this.isVisible;
  }

  select(option: string, index: number){;
      this.isVisible = !this.isVisible;
      this.selectedOption = option;
      const event = {'option': this.selectedOption, 'index': index}
      this.selectionDone.emit(event);
  }

}
