import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auditlog',
  templateUrl: './auditlog.component.html',
  styleUrls: ['./auditlog.component.css']
})
export class AuditlogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
