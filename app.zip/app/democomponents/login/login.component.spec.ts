// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { Router } from '@angular/router';
// import { Http, Headers, HttpModule } from '@angular/http';
// import { ActionDispatcherService, StateRepresentationRendererService, ModelPresenterService, EventTypeRegistryService } from 'usf-sam';

// import { LoginComponent } from './login.component';
// import { AuthenticationService } from '../../service/authentication.service'

// fdescribe('1st tests', () => {
//   it('true is true', () => expect(true).toBe(true))
// });

// fdescribe('LoginComponent', () => {
//   let component: LoginComponent;
//   let fixture: ComponentFixture<LoginComponent>;
//   let mockComponent: LoginComponent;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       imports: [HttpModule],
//       declarations: [ LoginComponent ],
//       providers: [
//         {provide: Router, useClass: RouterStub},
//         AuthenticationService,
//         ActionDispatcherService,
//         ModelPresenterService,
//         StateRepresentationRendererService,
//         EventTypeRegistryService
//       ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(LoginComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

// });

// class RouterStub{
//   navigateByUrl(url: string){
//     return url;
//   }
// }
