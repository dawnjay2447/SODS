import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import {
    FormGroup,
    FormControl,
    Validators,
    FormBuilder
} from '@angular/forms';
import { Http, Headers } from '@angular/http';
import { contentHeaders } from '../util/headers'; 
import { AuthenticationService } from '../../service/authentication.service'

@Component({
  selector: 'login',
  templateUrl: './login.component.html',  
  styleUrls: ['./login.component.css'],
})

export class LoginComponent implements OnInit {
  public error: Boolean;
  myform: FormGroup;
  username: FormControl;
  password: FormControl;
  actionCompleted:boolean = true;

  constructor(public router: Router, public http: Http, private authService : AuthenticationService) { }

  ngOnInit() { 
    this.error = false;

    this.username = new FormControl('', Validators.required);
    this.password = new FormControl('', Validators.required);

    this.myform = new FormGroup({
      username: this.username,
      password: this.password
    });
  }
  
  login(event, username, password) {
    this.actionCompleted = false;
    this.authService.loginService(username, password).subscribe(response => {        
        if(response.json().token != null && response.json().token != undefined && response.json().login == 'SUCCESS') {
          let obj = {"token": response.json().token};
          sessionStorage.setItem('token_obj', JSON.stringify(obj));
          sessionStorage.setItem('token', response.json().token);
          let expiration = new Date().getTime() + 30*60*1000;
          let record = {value: response.json().token, timestamp: expiration}
          localStorage.setItem('token', JSON.stringify(record));
          
          //Calls JWT parsing API for user info
          this.authService.fetchUser().subscribe(resp => {
            localStorage.setItem('user', JSON.stringify(resp));
            //if login success, store the username/password into the localstorage
            localStorage.setItem('username', username);
            localStorage.setItem('password', password);
            this.router.navigateByUrl('/search');
          });            
        } else {
          this.actionCompleted = true;
          this.error = true;
        }
    });
  }
}