import * as console from 'console';
import { Product } from './../../model/product';
import { ProductComponent } from './../common/product/product.component';
import {Component, OnInit, OnChanges, ViewChild, ViewEncapsulation, AfterViewInit, AfterContentChecked, SimpleChanges } from '@angular/core'; 
import {BaseComponent} from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import {ActionEvents, ModelChangeUpdateEvents} from "../../events/action-events";
import { Requisition } from '../../model/requisition';
import { Customer } from '../../model/customer';
import { CustomerComponent } from '../common/customer/customer.component';
import { UserComponent } from '../common/user/user.component';
import { Modal, ModalModule } from 'ngx-modal';
import { CreateRequisitionComponent } from '../common/createRequisition/createRequisition.component';
import { ShipToLocationComponent } from '../common/shipToLocation/shipToLocation.component'
import { AttachmentComponent } from '../common/attachment/attachment.component';

@Component({
    selector: 'so-new',
    templateUrl: './sodsnewso.component.html',
    styleUrls: ['./sodsnewso.component.css'],
})

export class SODSNewSoComponent extends BaseComponent implements OnInit, OnChanges, AfterViewInit, AfterContentChecked {
    @ViewChild('createRequisition') createRequisitionComponent: CreateRequisitionComponent
    @ViewChild('requisitionAttachments') attachmentComponent: AttachmentComponent;
    @ViewChild('sodsProduct') productComponent: ProductComponent;
    @ViewChild('shipToLocation') shipToLocation: ShipToLocationComponent;
    @ViewChild('warningError') warningErrorModal: Modal;
    @ViewChild('cancelPopup') cancelModal: Modal;
    @ViewChild('deleteReq') deleteReqModal: Modal;
    
    public elements: any[];
    reqId: string;
    shipCount: any = 0;
    closeErrorPopup: any = false;
    selectedReqType: any;
    errorsQueue: any[];
    successPost: boolean = false;
    successDraft: boolean = false;
    successDelete: boolean = false;

    constructor(readonly actionDispatcherService: ActionDispatcherService, readonly stateRepresentationRendererService: StateRepresentationRendererService) {
        super(stateRepresentationRendererService);
    }

    ngOnInit(){   
     this.errorsQueue = [];     
     this.elements = [
       {
        title: 'Requisition # :',
        isCollapsedReq: false
       },
       {
        title: 'Attachments',
        isCollapsedReq: true
       },
       {
        title: 'Ship To Locations',
        isCollapsedReq: true
       },
       {
        title: 'Product Information',
        isCollapsedReq: true
       }
     ];     

     let mapping: any = [];       
     mapping[ModelChangeUpdateEvents.POST_REQUISITION_SUCCESS] = (data: any) => { this.onPostSuccess(data); }
     mapping[ModelChangeUpdateEvents.POST_REQUISITION_FAIL] = (error: any) => { this.onPostFail(error); }
     mapping[ModelChangeUpdateEvents.DRAFT_REQUISITION_SUCCESS] = (data: any) => { this.onDraftSuccess(data); }
     mapping[ModelChangeUpdateEvents.DRAFT_REQUISITION_FAIL] = (error: any) => { this.onDraftFail(error); }
     mapping[ModelChangeUpdateEvents.REQ_CHANGE_EVT_SUCCESS] = () => { this.onValChange(); }
     mapping[ModelChangeUpdateEvents.DELETE_REQ_SUCCESS] = (error: any) => {this.deleteReqSuccess();}
     mapping[ModelChangeUpdateEvents.DELETE_REQ_FAIL] = (error: any) => {this.deleteReqFail(error);} 

     
     super.registerStateChangeEvents(mapping);

    }   

    onValChange() {
        this.successPost = false;
        this.successDraft = false;
    }

    ngOnChanges(changes: SimpleChanges) {
        this.successPost = false;
        this.successDraft = false;
    }

    onPostSuccess(data: any) {
       this.successPost = true;
       window.scrollTo(0,0);
        // window.location.reload();
    }

    onPostFail(error: any) {
        this.successPost = false;
        this.errorsQueue = [];
        if (error._body) {
            this.errorsQueue.push(error.statusText);
            this.errorsQueue.push(JSON.parse(error._body).message);
        } else {
            this.errorsQueue.push(error);
        }
        window.scrollTo(0,0);
    }

    onDraftSuccess(data: any) {
        this.closeWarning();
        this.successDraft = true;
        window.scrollTo(0,0);
        // window.location.reload();
    }

    onDraftFail(error: any) {
        this.closeWarning();
        this.successDraft = false;
        this.errorsQueue = [];
        if (error._body) {
            this.errorsQueue.push(error.statusText);
            this.errorsQueue.push(JSON.parse(error._body).message);
        } else {
            this.errorsQueue.push(error);
        }
        
        window.scrollTo(0,0);
    }

    ngAfterViewInit() {
    }

    ngAfterContentChecked() {
        this.reqId = this.createRequisitionComponent && this.createRequisitionComponent.reqId || '0000000'
        this.selectedReqType = this.createRequisitionComponent && this.createRequisitionComponent.selectedReqType;
        this.shipCount = this.shipToLocation && this.shipToLocation.shipmentCount;
        if (this.shipToLocation) {
            this.shipToLocation.selectedReqType = this.selectedReqType;
              this.shipToLocation.selectedMarket = this.createRequisitionComponent && this.createRequisitionComponent.selectedMarketingType   
            this.shipToLocation.marketingOptions = this.createRequisitionComponent.getMarketOptions
        }
       
    }

    getDateFormat(date: Date) {
        let d = '';
        d += date.getFullYear();
        d += '-' + (((date.getMonth() + 1) <= 9) ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1));
        d += '-' + date.getDate();
        d += ' ' + ((date.getHours() <= 9) ? '0' + date.getHours() : date.getHours());
        d += ':' + ((date.getMinutes() <= 9) ? '0' + date.getMinutes() : date.getMinutes());
        d += ':' + ((date.getSeconds() <= 9) ? '0' + date.getSeconds() : date.getSeconds());
        return d;
    }

    getDataObject() {
        const customersData = this.shipToLocation.data.map((item) => {
            return (
                {
                    "seq": item.customerNo,
                    "id": item.customer,
                    "dept": item.department,
                    "defaultShipMethod": item.ship_method,
                    "name": item.customerName,
                    "address1": item.address1,
                    "city": item.city,
                    "state": item.state,
                    "zip": item.zip,
                    "phone": item.phone,
                    estimatedOrderAmt: item.estimatedOrderAmt,
                    confidenceCode: item.confidenceCode,
                    creditCheckStatus: item.creditCheckStatus
                }
            );
                    // "estimatedOrderAmt":321.12,
                    // "confidenceCode":"09",
                    // "creditCheckStatus":true
        });

        return (
            {
                "requisition": 
                {
                    "requisitionNumber": this.createRequisitionComponent.requestId,
                    //"requisitionType": this.createRequisitionComponent.selectedReqType,
                    "requisitionType": "SODS-SO",
                    "division": this.createRequisitionComponent.selectedMarketingType,
                    "status":"new",
                    "createdAt": this.getDateFormat(new Date()),
                    "updatedAt": this.getDateFormat(new Date()),
                    "totalAmount":100.00,
                    "ETASelection": this.createRequisitionComponent.customerComponent.customerDetails.selectedETA !== 'Select Date',
                    "ETADate": this.getDateFormat(this.createRequisitionComponent.customerComponent.customerDetails.value),
                    "returnIfETANotMet": this.createRequisitionComponent.customerComponent.customerDetails.selectedETA === 'Select Date',
                    "defaultShipMethod": this.createRequisitionComponent.customerComponent.customerDetails.selectedShip,
                    "defaultCustomerPO": this.createRequisitionComponent.customerComponent.customerDetails.customerPO,
                    "defaultSpecInstructions":this.createRequisitionComponent.customerComponent.customerDetails.specialInstruct,
                    "mainCustomerID": this.createRequisitionComponent.customerComponent.customerDetails.id,
                    "mainCustomerName": this.createRequisitionComponent.customerComponent.customerDetails.name,
                    "mainCustomerDept": this.createRequisitionComponent.customerComponent.customerDetails.selectedDept || this.createRequisitionComponent.customerComponent.customerDetails.defaultDept,
                    "quotePrice": this.createRequisitionComponent.customerComponent.customerDetails.quotePrice,
                    "quoteNumber": this.createRequisitionComponent.customerComponent.customerDetails.quoteNbr,
                    "comments":
                    [
                    {
                                    "commentsText": this.createRequisitionComponent.customerComponent.customerDetails.comments,
                                    "timestamp": this.getDateFormat(new Date()),
                                    "networkId": JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId,
                                    "name": localStorage.getItem('username')
                    }
                    ]
                },
                "requestor":
                {
                    "name": this.createRequisitionComponent.requestor.name,
                    "networkId": this.createRequisitionComponent.requestor.networkId,
                    "email": this.createRequisitionComponent.requestor.email,
                    "additionalPhone": this.createRequisitionComponent.requestor.addlPhone || '',
                    "additionalEmail": this.createRequisitionComponent.requestor.addlEmail || ''
                },
                "territoryManager":
                {
                    "name": this.createRequisitionComponent.tm.name,
                    //"networkId": this.createRequisitionComponent.tm.networkId,
                    "networkId": "sodsus01",
                    "email": this.createRequisitionComponent.tm.email,
                    "additionalPhone": this.createRequisitionComponent.tm.addlPhone,
                    "additionalEmail": this.createRequisitionComponent.tm.addlEmail             
                },
                "customers": customersData,
                "products": this.productComponent.getProductsData()
            }
        );
    }
    onSubmitRequest() {
        window.console.log('we are here');
        this.successPost = false;
        this.closeErrorPopup = false;
        this.errorsQueue = [];
        const validationErrors = this.createRequisitionComponent.getRequiredErrors(true);
        if (validationErrors && validationErrors.length) {
            this.errorsQueue = this.errorsQueue.concat(validationErrors);
        }
        if (this.shipToLocation.data && this.shipToLocation.data.length === 0) {
            this.errorsQueue.push("Request must at least have 1 product.");
        }
        else if (this.shipToLocation.selectedReqType == 'Direct Ship' && this.shipToLocation.data.length !== 1) {
            this.errorsQueue.push("Please remove additional Ship to Location, Direct Ship requests can only be shipped to 1 location.");
        }
        if (this.shipToLocation.hasDuplicateValues()) {
            this.errorsQueue.push("Ship to should not have duplicates");
        }
        const productErrors = this.productComponent.checkCountOnProduct();
        if (productErrors.length > 0) {
            this.errorsQueue = this.errorsQueue.concat(productErrors);
        }
        if (this.errorsQueue.length === 0) {
            let body :any = this.getDataObject(); //define body here.. 
            body.draftTaskId = this.createRequisitionComponent.requestId;
            let event = this.actionDispatcherService.generateEvent(ActionEvents.POST_REQUISITION, body);
            this.actionDispatcherService.dispatch(event);
        } else {
            window.scrollTo(0,0);
        }
    }

    onSaveDraft() {
        window.console.log('we are here');
        this.successPost = false;
        this.closeErrorPopup = false;
        this.errorsQueue = [];
        const validationErrors = this.createRequisitionComponent.getRequiredErrors(false);
        if (validationErrors && validationErrors.length) {
            this.errorsQueue = this.errorsQueue.concat(validationErrors);
        }
        if (this.errorsQueue.length === 0) {
            this.cancelModal.close();
            this.warningErrorModal.open();
        } else {
          window.scrollTo(0,0);
        }
    }
    saveDaft() {
            let body:any = this.getDataObject(); //define body here..
            // localStorage.getItem('user') 
            window.console.log(localStorage.getItem('user'));
            body.requisition.status = "Draft";
            body.overideSavedByID = JSON.parse(JSON.parse(localStorage.getItem('user'))._body).userId;
            body.overideSavedByName = localStorage.getItem('username');
            let event = this.actionDispatcherService.generateEvent(ActionEvents.DRAFT_REQUISITION, body);
            this.actionDispatcherService.dispatch(event);
    }
    closeWarning() {
        this.warningErrorModal.close();
    }    
    onCancel() {
        this.cancelModal.open();
    }
    openCancelPopup() {
        this.cancelModal.close();
        window.location.reload();
    }
    closeCancelPopup() {
        this.cancelModal.close();
    }

    onDelete(){
        this.deleteReqModal.open();
    }

    closeDeleteRequisition(){
        this.deleteReqModal.close();
    }

    confirmDeleteReq(){
        let event = this.actionDispatcherService.generateEvent(ActionEvents.DELETE_REQ, this.createRequisitionComponent.reqId);
        this.actionDispatcherService.dispatch(event);
        this.deleteReqModal.close();
    }

    deleteReqSuccess(){
        this.successDelete = true;
        window.scrollTo(0,0);
    }

    deleteReqFail(error: any){
        this.successDelete = false;
        this.errorsQueue = [];
        if (error._body) {
            this.errorsQueue.push(error.statusText);
            this.errorsQueue.push(JSON.parse(error._body).message);
        } else {
            this.errorsQueue.push(error);
        }
        window.scrollTo(0,0);
    }
}