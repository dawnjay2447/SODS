import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit } from '@angular/core';
import { IMultiSelectOption, IMultiSelectSettings, IMultiSelectTexts } from '../../common/dropdown-multiselect/multiselect-dropdown';


@Component({
  selector: 'app-market-role-search',
  templateUrl: './market-role-search.component.html',
  styleUrls: ['./market-role-search.component.css']
})

export class MarketRoleSearchComponent implements OnInit, AfterViewInit {
  @Input() markets: string[];
  @Input() selectedMarket: string;
  @Input() selectedMarketNumber: string;
  @Input() marketOptions: string[];
  @Input() roleOptions: IMultiSelectOption[];
  @Input() selectedRoleOptions: number[];

  @Output('search')
  search: EventEmitter<any> = new EventEmitter<any>();

  @Output('roleSelect')
  roleSelect: EventEmitter<any> = new EventEmitter<any>();

  public roles: string[];

  public validMarketNumber = true;

  results: any[] = [];
  public multiSelectSettings: IMultiSelectSettings = {
    pullRight: true,
    enableSearch: false,
    checkedStyle: 'checkboxes',
    selectionLimit: 0,
    closeOnSelect: false,
    showCheckAll: false,
    showUncheckAll: false,
    showToggleCheckAll: true,
    dynamicTitleMaxItems: 0,
    maxHeight: '340px'
  };

  public multiSelectTexts: IMultiSelectTexts = {
    checkAll: 'Check All',
    uncheckAll: 'Uncheck All',
    toggleCheckAll: 'All Roles',
    checked: 'Selected',
    checkedPlural: 'Selected',
    searchPlaceholder: 'Search...',
    defaultTitle: 'Select Roles'
  };

  constructor() { }

  ngOnInit() {
    console.log(this.markets);
    
  }

  ngAfterViewInit() {
    console.log(this.markets);
    if (this.markets) {
      this.results = this.markets.map(x => x['divisionNumber'].toString());  
    }
  }

  onMarketNumTxtFieldBlur(divNumber) {
    // see if divNumber is valid
    
    this.validMarketNumber = this.isValidDivisionNumber(divNumber);
    // if valid, update the markets dropdown menu
    if (this.validMarketNumber) {
      this.selectedMarketNumber = divNumber;
      const index = this.markets.findIndex(x => x['divisionNumber'].toString() === this.selectedMarketNumber);
      this.setSelectedDivisonNumber(index);
      //this.getRolesForMarket();
    }
  }

  onMarketSelection(market): void {

    this.selectedMarket = market.option;
    this.setSelectedDivisonNumber(market.index);
  }

  public onChangeRoleSelection(roles): void {
    // Function is called when user checks an option
    // Input:  array of the selected option array indexes. ex) [0,1,2,3]

    // Set the selected roles array
    this.selectedRoleOptions = roles;
    console.log(this.selectedRoleOptions);
    this.roleSelect.emit(roles);
  }

  setSelectedDivisonNumber(index: number): void {
    const marketNumber = this.markets[index]['divisionNumber'] || '';
    this.selectedMarket = this.markets[index]['divisionName'] + '/' + this.markets[index]['divisionCode'];
    this.selectedMarketNumber = marketNumber;
    this.validMarketNumber = true;
  }

  isValidDivisionNumber(divNumber: string): boolean {
    return this.markets.some(market => market['divisionNumber'].toString() === divNumber);
  }

  onSearchBtnClick() {
    // Emit the Search Form Options to parent component
    // Output the selected division
    // Output the selected role
    let data: any = {'market': this.selectedMarketNumber, 'selectedRoles': this.selectedRoleOptions};
    this.search.emit(data);
  }

}
