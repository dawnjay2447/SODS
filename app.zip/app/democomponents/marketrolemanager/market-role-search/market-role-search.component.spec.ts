import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketRoleSearchComponent } from './market-role-search.component';

describe('MarketRoleSearchComponent', () => {
  let component: MarketRoleSearchComponent;
  let fixture: ComponentFixture<MarketRoleSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarketRoleSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketRoleSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
