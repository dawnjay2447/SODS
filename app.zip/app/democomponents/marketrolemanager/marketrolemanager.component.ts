import { Component, OnInit, OnDestroy } from '@angular/core';
import { BaseComponent } from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from '../../events/action-events';
import { DivisionUser } from '../../model/divisionrole';
import { IMultiSelectOption, IMultiSelectSettings, IMultiSelectTexts } from '../common/dropdown-multiselect/multiselect-dropdown';
import { Approver, Message } from '../../model/approver';
import { Role, RolesForDisplay } from '../../model/role';
import { BREADCRUMBS } from '../common/breadcrumb/breadcrumbs';

@Component({
    selector: 'app-market-role-manager',
    templateUrl: './marketrolemanager.component.html',
    styleUrls: ['./marketrolemanager.component.css']
})
export class MarketrolemanagerComponent extends BaseComponent implements OnInit, OnDestroy {
    // For Loading Indicator
    public loading = false;

    // For Breadcrumbs
    public breadcrumbs = BREADCRUMBS['market-role-manager'];

    // For Market Dropdown menu
    public markets: string[] = [];
    public selectedMarketNumber = '';
    public marketOptions = [];
    public selectedMarket = '';

    // For Role Multiselect Dropdown menu
    public roles: string[];
    public roleOptions: IMultiSelectOption[] = [];
    // Default roleOptions array indexes selected
    public selectedRoleOptions: number[];

    // For Approvers by Role Section
    public approvers: Array<Approver> = new Array<Approver>();
    public rolesForDisplay: Array<Role> = new Array<Role>();

    // For Alert Text Bar
    public showAlert = false;
    public alertType = '';
    public alertMessage = '';

    constructor(
        readonly actionDispatcherService: ActionDispatcherService,
        readonly stateRepresentationRendererService: StateRepresentationRendererService
    ) {
        super(stateRepresentationRendererService);

        const mapping: any = [];

        //  For loading the divisions in the market dropdown menu
        mapping[ModelChangeUpdateEvents.DIVISIONS_FOR_ROLE_SEARCH_SUCCESS] = (data: any) => {
            this.renderDivisionsForRoleSearch(data);
        };

        // For loading the approvers by role for a given market
        mapping[ModelChangeUpdateEvents.APPROVERS_FOR_MARKET_SUCCESS] = (data: any) => {
            this.renderRolesForMarket(data);
        };

        mapping[ModelChangeUpdateEvents.APPROVERS_FOR_MARKET_FAIL] = (data: any) => {
            this.renderRolesForMarketFail(data);
        };

        mapping[ModelChangeUpdateEvents.VALIDATE_APPROVERS_SUCCESS] = (data: any) => {
            this.renderValidationSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.VALIDATE_APPROVERS_FAIL] = (data: any) => {
            this.renderValidationFail(data);
        };

        super.registerStateChangeEvents(mapping);
    }

    ngOnInit() {

        this.initdata();
    }

    public initdata() {
        // Load Multiselect dropdown menu options
        this.roleOptions = Role.getRoleMenuOptions();
        this.selectedRoleOptions = Role.getDefaultSelectedRoleOptions();

        // Make an api call to get the divisions for the market dropdown menu
        const getDivisionsEvent = this.actionDispatcherService.generateEvent(ActionEvents.GET_DIVISIONS_FOR_ROLE_SEARCH, { 'data': '' });
        this.actionDispatcherService.dispatch(getDivisionsEvent);
    }

    roleSelect(event) {
        this.selectedRoleOptions = event;
    }

    public getRolesForMarket() {

        this.loading = true;
        this.alertMessage = '';
        this.showAlert = false;
        this.rolesForDisplay = [];

        // Dispatch an event to get the default roles
        const event = this.actionDispatcherService.generateEvent(
            ActionEvents.GET_APPROVERS_FOR_MARKET,
            { 'divisionNumber': this.selectedMarketNumber }
        );
        this.actionDispatcherService.dispatch(event);
    }

    public onChangeRoleSelection(roles): void {
        // Function is called when user checks an option
        // Input:  array of the selected option array indexes. ex) [0,1,2,3]

        // Set the selected roles array
        this.selectedRoleOptions = roles;

        /* Show/Hide Role based on the selected options
        // We are getting all roles back from the api call
        // no matter how many roles are selected from the dropdown
        // menu */

        // this.rolesForDisplay.forEach((role, index) => {
        //     role.isSelected = this.selectedRoleOptions.includes(index) ? true : false;
        // });
    }

    search(event) {
        this.selectedMarketNumber = event.market;
        this.selectedRoleOptions = event.selectedRoles;
        this.getRolesForMarket();
    }

    // Start of Render Functions

    public renderDivisionsForRoleSearch(divResponse) {
        this.markets = divResponse;
        this.markets.forEach((market) => {
            const option = market['divisionName'] + '/' + market['divisionCode'];
            this.marketOptions.push(option);
        });

        this.selectedMarketNumber = this.markets[0]['divisionNumber'];
        this.selectedMarket = this.markets[0]['divisionName'] + '/' + this.markets[0]['divisionCode'];
    }

    renderRolesForMarket(response) {
        if (response.approvers) {
            this.approvers = response.approvers;
            const roles = new RolesForDisplay();

            this.rolesForDisplay = roles.getRoles();

            // Format Data for display
            let formattedData = this.groupBy(response.approvers, 'roleID');
            formattedData = this.formatDataForDisplay(formattedData);

            // Replace rolesForDisplay with actual approver values if they exist
            const matches = formattedData.filter((o1) => {
                return this.rolesForDisplay.some((o2) => {
                    return o1['roleID'] === o2['roleID'];
                });
            });

            matches.forEach((row) => {
                const index = this.rolesForDisplay.findIndex(x => x.roleID === row.roleID);
                this.rolesForDisplay[index] = row;
            });

            this.rolesForDisplay.forEach((role, i) => {
                role['isSelected'] = this.selectedRoleOptions.indexOf(i) !== -1 ? true : false;
            });

            this.loading = false;
        }
    }

    renderRolesForMarketFail(response) {
        this.loading = false;
        this.approvers = [];
        this.rolesForDisplay = [];
        const roles = new RolesForDisplay();
        this.rolesForDisplay = roles.getRoles();
        this.rolesForDisplay.forEach((role, i) => {
            role['isSelected'] = this.selectedRoleOptions.indexOf(i) !== -1 ? true : false;
        });

    }

    renderValidationSuccess(response) {
        console.log(response);
    }

    renderValidationFail(response) {

    }

    validateApprovers(approvers) {
        this.approvers = approvers;

        // Format request
        const request = {
            'approvers': [
                {
                    'status': 'string',
                    'statusDesc': 'string',
                    'allOOO': 'string',
                    'approver': approvers
                }
            ]
        };

        // Dispatch an event to validate the approvers
        const event = this.actionDispatcherService.generateEvent(
            ActionEvents.VALIDATE_APPROVERS,
            { 'body': request }
        );
        this.actionDispatcherService.dispatch(event);
    }

    // Start of Utility Functions
    groupBy(arr, property) {
        return arr.reduce(function (all, x) {
            if (!all[x[property]]) { all[x[property]] = []; }
            all[x[property]].push(x);
            return all;
        }, {});
    }

    formatDataForDisplay(obj) {
        // This will restructure the Approvers array
        // in order to allow for dynamic display in template
        // It requires the Approvers array to be grouped by the roleID

        let newObj = {};
        let levelsArray = [];
        const marketRoles = [];
        const roles = new Array<Role>();

        for (const p in obj) {
            if (obj.hasOwnProperty(p)) {
                const levels = this.groupBy(obj[p], 'level');
                for (const q in levels) {
                    if (levels.hasOwnProperty(q)) {
                        levelsArray = Object.keys(levels).map(function (key) {
                            return levels[key];
                        });
                    }
                }

                newObj = {
                    'roleID': p,
                    'isCollapsed': false,
                    'isSelected': true,
                    'roleName': Role.getRoleName(p),
                    'levels': levelsArray
                };
                marketRoles.push(newObj);
            }
        }
        return marketRoles;
    }

    expandAll() {
        this.rolesForDisplay.forEach((role) => {
            role.isCollapsed = false;
        });
    }

    collapseAll() {
        this.rolesForDisplay.forEach((role) => {
            role.isCollapsed = true;
        });
    }

    toggleCollapse(rowId) {
    }

    handleAlert(event) {
        this.alertType = event.alertType;
        this.alertMessage = event.alertTxt;

        this.displayAlert();
    }

    displayAlert() {
        this.showAlert = true;

        setTimeout(() => {
            this.showAlert = false;
        }, 4000);
    }

    ngOnDestroy() {
        super.ngOnDestroy();
    }
}
