import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketrolemanagerComponent } from './marketrolemanager.component';

describe('MarketrolemanagerComponent', () => {
  let component: MarketrolemanagerComponent;
  let fixture: ComponentFixture<MarketrolemanagerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarketrolemanagerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketrolemanagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
