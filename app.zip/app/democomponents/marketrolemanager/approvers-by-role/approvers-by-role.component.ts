import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { Role } from '../../../model/role';
import { Approver } from '../../../model/approver';
import { Modal } from 'ngx-modal';

@Component({
  selector: 'app-approvers-by-role',
  templateUrl: './approvers-by-role.component.html',
  styleUrls: ['./approvers-by-role.component.css']
})
export class ApproversByRoleComponent implements OnInit {
  // Input
  @Input() rolesForDisplay: Array<Role>;
  @Input() approvers: Array<Approver>;
  @Input() selectedMarketNumber: string;
  @Input() error: string;

  // Output
  @Output('alert')
  alert: EventEmitter<any> = new EventEmitter<any>();
  @Output('validate')
  validate: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild('confirmDelete') confirmDeleteLevelModal: Modal;

  deletedRoleId: number;
  deletedLevelId: number;
  errorString: string;
  constructor() {
  }

  ngOnInit() {
    this.errorString = this.error;
  }

  addLevel(roleID) {
    // Adds an additional approver level to the selected role
    // Max # of levels is 5
    if (this.rolesForDisplay[roleID].levels.length < 5) {
      this.rolesForDisplay[roleID].levels.push([]);
    }
  }

  deleteLevel(roleID, levelId) {
    if (this.rolesForDisplay[roleID].levels.length > 1 || this.rolesForDisplay[roleID].roleID === 'NIA') {
      // Deletes an approver level from the selected role
      this.rolesForDisplay[roleID].levels.splice(levelId, 1);
    } else {
      this.errorString = this.selectedMarketNumber + '-' + roleID + '-' + levelId;
      this.alert.emit({'alertType': 'error', 'alertTxt': 'level-one-required', 'showAlert': true});
      this.handleError(this.errorString);
    }

  }

  handleError(error) {
    setTimeout(() => {
      this.errorString = '';
      this.error = '';
    }, 4000);
  }

  isError(roleID, levelId) {
    //alert(roleID);
    return this.errorString === this.selectedMarketNumber + '-' + roleID + '-' + levelId;
  }

  addApprover(roleID, levelId, networkId, event) {
    // Function is called on keyup event from the Approver input txt field

    // If the keyboard event is space or enter
    if (event.keyCode == '32' || event.keyCode == '13') {
      // If the entered text length is at least 3 characters
      // Create a new Approver
      if (event.target.value.length >= 3) {
        const approver = new Approver();
        approver.division = this.selectedMarketNumber;
        approver.userId = networkId.replace(' ', '');
        approver.level = levelId + 1;
        approver.roleID = this.rolesForDisplay[roleID].roleID;
        approver.roleName = this.rolesForDisplay[roleID].roleName;
        this.approvers.push(approver);
        this.rolesForDisplay[roleID].levels[levelId].push(approver);
        event.target.value = '';
      }
    }
  }

  onBlurAddApprover(roleID, levelId, networkId, event) {
    if (event.target.value.length >= 3) {
      const approver = new Approver();
      approver.division = this.selectedMarketNumber;
      approver.userId = networkId;
      approver.level = levelId + 1;
      approver.roleID = this.rolesForDisplay[roleID].roleID;
      approver.roleName = this.rolesForDisplay[roleID].roleName;
      this.approvers.push(approver);
      this.rolesForDisplay[roleID].levels[levelId].push(approver);
      event.target.value = '';
    }
  }

  deleteApprover(roleID, levelId, userId) {
    // Deletes an approver
    this.rolesForDisplay[roleID].levels[levelId].splice(userId, 1);
  }

  expandAll() {
    this.rolesForDisplay.forEach((role) => {
      role.isCollapsed = false;
    });
  }

  collapseAll() {
    this.rolesForDisplay.forEach((role) => {
      role.isCollapsed = true;
    });
  }

  toggleCollapse(rowId) {
  }

  openDeleteModal(roleID, levelId) {
    this.deletedRoleId = roleID;
    this.deletedLevelId = levelId;
    if (this.rolesForDisplay[roleID]['levels'][levelId].length > 0) {
      this.confirmDeleteLevelModal.open();
    } else {
      this.deleteLevel(roleID, levelId);
    }
  }

  onDeleteLevel() {
    this.confirmDeleteLevelModal.close();
    this.deleteLevel(this.deletedRoleId, this.deletedLevelId);
  }

  closeDeleteModal() {
    this.confirmDeleteLevelModal.close();
  }

  saveApprovers() {

  }

  validateApprovers() {
    this.validate.emit(this.approvers);
  }

  export() {

  }

  cancel() {
    this.rolesForDisplay = [];
  }

}
