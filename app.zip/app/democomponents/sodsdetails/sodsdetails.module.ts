import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from  '../../shared/shared.module';
import { RouterModule } from '@angular/router';
import { SodsdetailsComponent } from '../sodsdetails/sodsdetails.component';

import { routing } from './sodsdetails.routes';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    routing
  ],
  declarations: [
    SodsdetailsComponent
  ]
})
export class SodsdetailsModule { }
