import { RouterModule } from '@angular/router';
import { SodsdetailsComponent } from './sodsdetails.component';
import { AuthGuard } from '../util/auth.guard';

export const sodsDetailsRoutes=[
    { path: ':reqId', component: SodsdetailsComponent, canActivate: [AuthGuard] }
];

export const routing = RouterModule.forChild(sodsDetailsRoutes);