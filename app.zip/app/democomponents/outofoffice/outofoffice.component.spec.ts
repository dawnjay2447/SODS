import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OutofofficeComponent } from './outofoffice.component';

describe('OutofofficeComponent', () => {
  let component: OutofofficeComponent;
  let fixture: ComponentFixture<OutofofficeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OutofofficeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutofofficeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
