import { HeaderComponent } from './../header/header.component';
import { BaseComponent } from '../base-component';
import { ActionDispatcherService, StateRepresentationRendererService } from 'usf-sam';
import { ActionEvents, ModelChangeUpdateEvents } from '../../events/action-events';
import { Component, OnInit, OnDestroy } from '@angular/core';


@Component({
  selector: 'app-outofoffice',
  templateUrl: './outofoffice.component.html',
  styleUrls: ['./outofoffice.component.scss']
})
export class OutofofficeComponent extends BaseComponent implements OnInit, OnDestroy {
  isShow: boolean = false;
  date_selection_error: boolean = false;
  minDate: Date = new Date();
  value: Date = new Date();
  selectedType: string;
  results: any[];
  forwardTask: any;
  isUpdateSuccess: any = false;
  isUpdateError: any = false;

  constructor(
        readonly actionDispatcherService: ActionDispatcherService,
        readonly stateRepresentationRendererService: StateRepresentationRendererService
    ) {
        super(stateRepresentationRendererService);

        const mapping: any = [];

        //  For loading the divisions in the market dropdown menu
        mapping[ModelChangeUpdateEvents.TASKS_TO_SEARCH_SUCCESS] = (data: any) => {
            this.renderTasksTo(data);
        };

        // For loading the approvers by role for a given market
        mapping[ModelChangeUpdateEvents.OUT_OF_OFFICE_UPDATE_SUCCESS] = (data: any) => {
            this.onSubmitSuccess(data);
        };

        mapping[ModelChangeUpdateEvents.TASKS_TO_SEARCH_FAIL] = (data: any) => {
            this.renderTasksToFail(data);
        };

        mapping[ModelChangeUpdateEvents.OUT_OF_OFFICE_UPDATE_FAIL] = (data: any) => {
            this.onSubmitFail(data);
        };

        super.registerStateChangeEvents(mapping);
    }
  renderTasksTo(data) {
    this.results = data;
  }

  renderTasksToFail(err) {

  }

  onSubmitSuccess(data) {
    this.isUpdateSuccess = true;
  }

  onSubmitFail(data) {
    this.isUpdateError = true;
  }

  submitOutofOffice() {
    this.isUpdateSuccess = false;
    this.isUpdateError = false;
  }



  ngOnInit() {
  }
  showOutOfOffice() {
    this.isShow = true;
  }
  onDateSelectionDone() {
    this.date_selection_error = false;
  }
  onErrorHandler() {
    this.date_selection_error = true;
  }
  onChangeRadio(val) {
    this.selectedType = val;
  }

  onChange() {
    
  }

  
}
