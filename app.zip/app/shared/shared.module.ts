import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule ,ReactiveFormsModule} from '@angular/forms';
import { ProductComponent } from '../democomponents/common/product/product.component';
import { ProductAttachmentComponent } from './../democomponents/common/product/product-attachment.component';
import { CustomerComponent } from '../democomponents/common/customer/customer.component';
import { EditCustomerComponent } from '../democomponents/common/customer/edit-customer.component';
import { CustomerDetailsComponent } from '../democomponents/common/customer/customer-details.component';
import { UserComponent } from '../democomponents/common/user/user.component';
import { ShiptodistComponent } from '../democomponents/common/shiptodist/shiptodist.component';
import { AddShipToComponent } from '../democomponents/common/shiptodist/add-ship-to.component';
import { AttachmentComponent } from '../democomponents/common/attachment/attachment.component';
import { ProductShipToDistComponent } from '../democomponents/common/shiptodist/product-ship-to-dist.component';
import { AttachfileComponent } from '../democomponents/common/attachment/attachfile.component';
import { AuditlogComponent } from '../democomponents/common/auditlog/auditlog.component';
import { VendorComponent } from '../democomponents/common/vendor/vendor.component';
import { AddNewProductComponent } from '../democomponents/common/product/add-new-product.component';
import { AddExistingProductComponent } from '../democomponents/common/product/add-existing-product.component';
import { UploadProductComponent } from '../democomponents/common/product/upload-product.component';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from '../democomponents/header/header.component';
import { DropdownComponent } from '../democomponents/common/dropdown/dropdown.component';
import { MarketDropdownComponent } from '../democomponents/common/dropdown/market-dropdown/market-dropdown.component';
import { ShipToDropdownComponent } from '../democomponents/common/dropdown/shipTo-dropdown/ship-to-dropdown.component';
import { Collapse } from '../directive/collapse.component';
import { ModalModule, Modal } from 'ngx-modal';
import {CalendarModule} from 'primeng/primeng';
import {AutoCompleteModule} from 'primeng/primeng';
import { CalendarComponent } from '../democomponents/common/calendar/calendar.component';
import { AutoCompleteComponent } from '../democomponents/common/auto-complete/autoComplete.component';

import { CreateRequisitionComponent } from '../democomponents/common/createRequisition/createRequisition.component';
import { ShipToLocationComponent } from '../democomponents/common/shipToLocation/shipToLocation.component';
import { AddShipToLocationComponent } from '../democomponents/common/shipToLocation/add-shipToLocation.component';
import { EditShipToLocationComponent } from '../democomponents/common/shipToLocation/edit-shipToLocation.component';

import { ProductCommentComponent } from '../democomponents/common/comment/product-comment/product-comment.component';
import { EditNewProductComponent } from '../democomponents/common/product/edit-new-product.component';
import { EditExistingProductComponent } from '../democomponents/common/product/edit-existing-product.component';
import { EditFileComponent } from '../democomponents/common/attachment/edit-file.component';
import { MultiselectDropdownModule } from '../democomponents/common/dropdown-multiselect/multiselect-dropdown';
import { RoleManDropdownComponent } from '../democomponents/common/dropdown/roleManager-dropdown/dropdown.component';
import { BreadcrumbComponent } from '../democomponents/common/breadcrumb/breadcrumb.component';
import { SpinnerComponent } from '../democomponents/common/spinner/spinner.component';
import { AlertComponent } from '../democomponents/common/alert/alert.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ModalModule,
    CalendarModule,
    AutoCompleteModule,
    RouterModule,
    MultiselectDropdownModule
  ],
  declarations: [
    ProductComponent,
    ProductAttachmentComponent,
    CustomerComponent,
    UserComponent,
    ShiptodistComponent,
    AttachmentComponent,
    AttachfileComponent,
    AuditlogComponent,
    VendorComponent,
    EditCustomerComponent,
    AddNewProductComponent,
    AddExistingProductComponent,
    UploadProductComponent,
    AddShipToComponent,
    HeaderComponent,
    ProductShipToDistComponent,
    DropdownComponent,
    MarketDropdownComponent,
    ShipToDropdownComponent,
    CustomerDetailsComponent,
    Collapse,
    CalendarComponent,
    AutoCompleteComponent,
    CreateRequisitionComponent,
    ShipToLocationComponent,
    AddShipToLocationComponent,
    EditShipToLocationComponent,
    ProductCommentComponent,
    EditNewProductComponent,
    EditExistingProductComponent,
    EditFileComponent,
    RoleManDropdownComponent,
    BreadcrumbComponent,
    SpinnerComponent,
    AlertComponent
  ],
  exports:[
    CommonModule,
    FormsModule,
    MultiselectDropdownModule,
    ProductComponent,
    CustomerComponent,
    UserComponent,
    ShiptodistComponent,
    AttachmentComponent,
    AuditlogComponent,
    VendorComponent,
    HeaderComponent,
    ProductShipToDistComponent,
    DropdownComponent,
    MarketDropdownComponent,
    ShipToDropdownComponent,
    CustomerDetailsComponent,
    Collapse,
    CalendarComponent,
    AutoCompleteComponent,
    CreateRequisitionComponent,
    ShipToLocationComponent,
    AddShipToLocationComponent,
    EditShipToLocationComponent,
    ProductCommentComponent,
    EditNewProductComponent,
    EditExistingProductComponent,
    RoleManDropdownComponent,
    BreadcrumbComponent,
    SpinnerComponent,
    ModalModule,
    Modal,
    AlertComponent
  ]
})

export class SharedModule { }