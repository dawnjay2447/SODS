import { Approver } from './approver';

export class Role {
    static roleMap = {
        'NIA': 'New Product Approver',
        'CMFP': 'Category Manager Food - Perishable',
        'CMFNP': 'Category Manager Food - Non-Perishable',
        'CMFC': 'Category Manager Food - COP',
        'CMF': 'Category Manager Food',
        'CMNF': 'Category Manager Non-Foods',
        'CMES': 'Category Manager CE&S',
        'RSFP': 'Product Attachment Food - Perishable',
        'RSFNP': 'Product Attachment Food - Non-Perishable',
        'RSF': 'Product Attachment Food',
        'RSNF': 'Product Attachment Non-Food',
        'RSES': 'Product Attachment ES',
        'CA': 'Credit Analyst',
        'DSM': 'District Sales Manager',
        'RSM': 'Regional Sales Manager',
        'VP': 'VP of Local Sales',
        'BUYER': 'Buyer Backup',
        'DSB': 'Direct Ship Buyer',
        'FM': 'District Sales Support'
    };

    roleID: string;
    roleName: string;
    isCollapsed: boolean;
    isSelected: boolean;
    levels: [any[]];

    public static getRoleName(roleID: string) {
        return this.roleMap[roleID];
    }

    static getRoleMenuOptions() {

        const options = [];
        Object.keys(this.roleMap).forEach((role, id) => {
            const item = {'id': id, 'name': this.roleMap[role]};
            options.push(item);
        });
        console.log(options);
        return options;
    }

    static getDefaultSelectedRoleOptions() {
        const options = []
        Object.keys(this.roleMap).forEach((role, id) => {
            options.push(id);
        });
        return options;
    }

    constructor(roleID: string, isCollapsed: boolean, roleName: string) {
        this.roleID = roleID;
        this.isCollapsed = isCollapsed;
        this.roleName = roleName;
        this.isSelected = false;
        this.levels = [new Array<Approver>()];
    }
}

export class RolesForDisplay {
    roles: Array<Role> = [];

    constructor() {
        this.roles = new Array<Role>();
        this.roles.push(new Role('NIA', true, Role.getRoleName('NIA')));
        this.roles.push(new Role('CMFP', true, Role.getRoleName('CMFP')));
        this.roles.push(new Role('CMFNP', true, Role.getRoleName('CMFNP')));
        this.roles.push(new Role('CMFC', true, Role.getRoleName('CMFC')));
        this.roles.push(new Role('CMF', true, Role.getRoleName('CMF')));
        this.roles.push(new Role('CMNF', true, Role.getRoleName('CMNF')));
        this.roles.push(new Role('CMES', true, Role.getRoleName('CMES')));
        this.roles.push(new Role('RSFP', true, Role.getRoleName('RSFP')));
        this.roles.push(new Role('RSFNP', true, Role.getRoleName('RSFNP')));
        this.roles.push(new Role('RSF', true, Role.getRoleName('RSF')));
        this.roles.push(new Role('RSNF', true, Role.getRoleName('RSNF')));
        this.roles.push(new Role('RSES', true, Role.getRoleName('RSES')));
        this.roles.push(new Role('CA', true, Role.getRoleName('CA')));
        this.roles.push(new Role('DSM', true, Role.getRoleName('DSM')));
        this.roles.push(new Role('RSM', true, Role.getRoleName('RSM')));
        this.roles.push(new Role('VP', true, Role.getRoleName('VP')));
        this.roles.push(new Role('BUYER', true, Role.getRoleName('BUYER')));
        this.roles.push(new Role('DSB', true, Role.getRoleName('DSB')));
        this.roles.push(new Role('FM', true, Role.getRoleName('FM')));
    }

    setSelectedRoles(selectedRoles: number[]): Array<Role> {
        selectedRoles.forEach((index) => {
            this.roles[index].isSelected = true;
        });
        return this.roles;
    }

    getRoles() {
        return this.roles;
    }
}
