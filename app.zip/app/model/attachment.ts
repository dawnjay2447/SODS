export class Attachment{
    fileName: string;
    comments: string;
    type: string;
    updatedBy: string;
    uploadDate: string;
    requisitionId: string;
    selected: boolean;
}

export const SAMPLEATTACHMENT_A : Attachment = {
    fileName: "attachment A",
    comments: "attachment A comments",
    type: "pdf",
    updatedBy: "Wen",
    uploadDate: "01/01/2017",
    requisitionId: "3434",
    selected: false
}

export const SAMPLEATTACHMENT_B : Attachment = {
    fileName: "attachment B",
    comments: "attachment B comments",
    type: "excel",
    updatedBy: "Amber",
    uploadDate: "02/01/2017",
    requisitionId: "3434",
    selected: false
}

export const SAMPLEAttachmentArr: Attachment[] = [SAMPLEATTACHMENT_A, SAMPLEATTACHMENT_B];