export class TandemTM {
    "status": string;
    "statusDescription": string;
    "routeToDivision": string;
    "routeToDSMID": string;
    "routeToRSMID": string;
    "routeToVPID": string;
    "routeToFMID": string;
    "routeToDivisionCode": string;
    "routeToDivisionSystem": string;
    "routeToDivisionTimezone": string;
    "tmtandemID": string;
    "tmnetworkID": string;
    "tmparentDivision": string;
}

export const SAMPLETandemTM: TandemTM = {
    "status": "Success",
    "statusDescription": "",
    "routeToDivision": "6026",
    "routeToDSMID": "VYU6026",
    "routeToRSMID": "VYU6026",
    "routeToVPID": "VYU6026",
    "routeToFMID": "VYU6026",
    "routeToDivisionCode": "",
    "routeToDivisionSystem": "",
    "routeToDivisionTimezone": "",
    "tmtandemID": "QFS6026",
    "tmnetworkID": "SODSUS02",
    "tmparentDivision": "1104"
}