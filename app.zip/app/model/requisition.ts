import { Customer, SAMPLECUSTOMER } from './customer';

export class User{
    name: string;
    networkId: string;
    email: string;
}

export const SAMPLEREQUESTR: User = {
    name: 'sodsus01, Shared',
    networkId: 'sodsus01',
    email: 'Shared.sodsus01@foodfile.com'
}

export const SAMPLETM: User = {
    name: 'sodsus02, Shared',
    networkId: 'sodsus02',
    email: 'Shared.sodsus02@foodfile.com'
}

export class Requisition{
    reqId: string;
    type: string;
    division: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    totalAmount: string;
    etaSelection: boolean;
    returnIfETANotMet: boolean;
    defaultShipMethod: string;
    defaultCustomerPO: string;
    defaultSpecInstructions: string;
    mainCustomerID: string;
    mainCustomerName: string;
    mainCustomerDept: string;
    requestor: User;
    tm: User;
    customer: Customer;

}

export const SAMPLEREQUISITION: Requisition = {
    reqId: '9789',
    type: 'SODS-SO',
    division: '1104',
    status: 'Purchasing/Ordering/Shipping in Progress',
    createdAt: '2016-09-29 13:44:07',
    updatedAt: '2016-09-29 13:44:07',
    etaSelection: false,
    returnIfETANotMet: false,
    totalAmount: '321.12',
    defaultShipMethod: 'Separate',
    defaultCustomerPO: '124540',
    defaultSpecInstructions: 'TESTING',
    mainCustomerID: '60528643',
    mainCustomerName: 'DBL TREE CLEVE DT/LAKESD*',
    mainCustomerDept: '10-FOOD',
    requestor: SAMPLEREQUESTR,
    tm: SAMPLETM,
    customer: SAMPLECUSTOMER
};

