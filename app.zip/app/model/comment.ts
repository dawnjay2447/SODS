export class Comment{
    commentText: string;
    timeStamp: Date;
    netWorkId: string;
    name: string;
}

export const SAMPLECommentA: Comment = {
    commentText: 'abcdlajflsjfladsjfalsdjfalsjfdlsajfladsjflasdjflasdjflasjdflasj',
    timeStamp: new Date(),
    netWorkId: 'test',
    name: 'Wen, Liang'
}

export const SAMPLECommentB: Comment = {
    commentText: 'sjfldsajfldasjfladsjflasdjflsadjlvmfaonvoaijeoincalmclajclasjfaposdjf',
    timeStamp: new Date(),
    netWorkId: 'test',
    name: 'Karthik, Balasubramanian'
}

export const SAMPLECommentArr: Comment[] = [SAMPLECommentA, SAMPLECommentB];