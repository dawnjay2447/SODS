export class Approver {
    action: string;
    applicationID: string;
    division: string;
    roleID: string;
    level: string;
    userId: string;
    firstName: string;
    lastName: string;
    email: string;
    outofOffice: string;
    designatedID: string;
    returnDate: string;
    messages: Message[];
    roleName: string;

    constructor() {
        const messageArray = new Array<Message>();
        messageArray.push(new Message());
        this.action = '';
        this.applicationID = '1';
        this.division = '';
        this.roleID = '';
        this.level = '';
        this.userId = '';
        this.firstName = '';
        this.lastName = '';
        this.email = '';
        this.outofOffice = 'false';
        this.designatedID = '';
        this.returnDate = '';
        this.messages = messageArray;
    }
}

export class Message {
    type: string;
    desc: string;

    constructor() {
        this.type = '';
        this.desc = '';
    }
}
