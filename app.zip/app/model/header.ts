export class Header {
    correlationId: string
    clientId: string
    transId: string
    replyCd: string
    recptId: string
    userId: string
    logTxt: string
    replyMsg: string
}

export const SAMPLEHEADER : Header = {
    correlationId: '0',
    clientId: 'SODS',
    transId: '0',
    replyCd: '0',
    recptId: '0',
    userId: 'SODS',
    logTxt: '0',
    replyMsg: '0'
}