export class ObjectKey{
    objectKey: any;
    name: string;
    requisitionId: string;
}